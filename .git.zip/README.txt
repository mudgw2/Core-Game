CORE 0.1.84 — Character / Universe Assignment

BASELINE
--------
Apply this patch to CORE 0.1.83.

INSTALL
-------
1. Back up the current CORE project directory.
2. Extract this ZIP into the CORE project root.
3. Allow the archive to overwrite the listed files.
4. Confirm config/version.php reports 0.1.84.
5. Run the CLI QA suite: php tests/run.php
6. Run the development-only browser QA endpoint from the local/private network.

CHANGES
-------
- Adds CharacterUniverseAssignmentService as the single assignment path.
- Serializes assignment using the universe lock followed by the character lock,
  matching the existing universe deletion lock order.
- Verifies character ownership and both character/universe lifecycle state.
- Initializes the character's starting system, location, and exploration record.
- Increments the character revision on first assignment.
- Makes repeat assignment to the same universe idempotent without resetting
  location, exploration, or other character progress.
- Rejects reassignment to a different universe.
- Routes player universe creation through the assignment service.
- Rejects already-assigned or locked characters before creating a new universe.
- Adds regression coverage and advances the release/cache version to 0.1.84.

DATA
----
No existing storage records are rewritten by this patch.
No storage/data or player-account files are included in this ZIP.
No database migration is required.

VALIDATION
----------
Browser QA: 130 passed, 0 failed.
CLI QA: CORE QA summary: 73 passed, 0 failed.
PHP syntax: 84 files clean.
JavaScript syntax: 4 files clean.

The QA endpoint remains development-only and must be disabled before public
exposure, as documented in the existing project configuration.
