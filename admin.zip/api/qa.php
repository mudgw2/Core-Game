<?php
declare(strict_types=1);

/**
 * Browser-triggered, development-only QA suite. Tests use temporary storage.
 * Disable config.qa.enabled before exposing CORE outside a trusted development LAN.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$root = dirname(__DIR__);
define('CORE_ROOT', $root);
require $root . '/bootstrap.php';

$configFile = $root . '/config/app.php';
$config = is_file($configFile) ? require $configFile : [];
$remote = (string)($_SERVER['REMOTE_ADDR'] ?? '');
$isLocal = in_array($remote, ['127.0.0.1', '::1'], true)
    || preg_match('/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/', $remote) === 1
    || str_starts_with(strtolower($remote), 'fc')
    || str_starts_with(strtolower($remote), 'fd');
if (empty($config['qa']['enabled']) || ($config['app']['environment'] ?? 'production') !== 'development' || !$isLocal) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => ['code' => 'qa_disabled', 'message' => 'Browser QA is disabled or this client is not on a permitted local network.']], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo json_encode(['ok' => false, 'error' => ['code' => 'method_not_allowed', 'message' => 'Use POST to run QA.']], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

use Core\Modules\Universe\UniverseGenerator;
use Core\Modules\Universe\WorldGenerator;
use Core\Modules\Characters\CharacterService;
use Core\Modules\Characters\CharacterTravelService;
use Core\Modules\Characters\CharacterScanService;
use Core\Modules\Characters\CharacterDiscoveryService;
use Core\Modules\Characters\CharacterCraftingService;
use Core\Modules\Characters\CharacterFittingService;
use Core\Modules\Characters\CharacterLifecycleService;
use Core\Modules\Universe\UniverseService;
use Core\Modules\Universe\UniverseLifecycleService;
use Core\Modules\Universe\NavigationGraph;
use Core\Modules\Universe\NavigationRouteService;
use Core\Storage\JsonStorage;
use Core\Modules\DataManagementService;
use Core\Modules\UniverseBackupService;
use Core\Modules\ContentCatalog;
use Core\Modules\ContentManagementService;
use Core\Modules\UniverseDeletionService;

$results = [];
$run = static function (string $name, callable $test) use (&$results): void {
    try {
        $details = $test();
        $results[] = ['name' => $name, 'status' => 'PASS', 'details' => is_string($details) ? $details : 'Passed'];
    } catch (Throwable $e) {
        $results[] = ['name' => $name, 'status' => 'FAIL', 'details' => $e->getMessage()];
    }
};
$assert = static function (bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
};
$equal = static function (mixed $expected, mixed $actual, string $message): void {
    if ($expected !== $actual) throw new RuntimeException($message);
};
$cleanup = static function (string $dir): void {
    if (!is_dir($dir)) return;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $item) $item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname());
    rmdir($dir);
};

/** Read the complete Workbench source, including its externalized assets.
 * Static UI checks must inspect the shipped HTML and JavaScript together;
 * otherwise a valid extraction from index.php into assets/admin.js appears missing.
 */
function coreWorkbenchSource(string $root): string {
    $parts = [];
    foreach (['index.php', 'assets/admin.js', 'assets/admin.css'] as $relative) {
        $path = $root . '/' . $relative;
        $contents = is_file($path) ? file_get_contents($path) : false;
        if (!is_string($contents)) {
            throw new RuntimeException('Workbench source could not be read: ' . $relative);
        }
        $parts[] = $contents;
    }
    return implode("\n/* CORE source boundary */\n", $parts);
}

$run('Same seed produces identical baseline', static function () use ($equal): string {
    $g = new UniverseGenerator();
    $equal($g->generate('core-ui-qa-seed'), $g->generate('core-ui-qa-seed'), 'Baseline differs for the same seed.');
    return 'Repeated generation matched exactly.';
});
$run('Seed whitespace is normalized', static function () use ($equal): string {
    $g = new UniverseGenerator();
    $equal($g->generate('  core-ui-qa-seed  '), $g->generate('core-ui-qa-seed'), 'Whitespace normalization mismatch.');
    return 'Trimmed and untrimmed seeds matched.';
});
$run('Different seeds produce different universe IDs', static function () use ($assert): string {
    $g = new UniverseGenerator();
    $assert($g->generate('core-ui-qa-alpha')['id'] !== $g->generate('core-ui-qa-beta')['id'], 'Different seeds returned the same ID.');
    return 'Distinct seeds produced distinct IDs.';
});
$run('Generated system structure and coordinates are valid', static function () use ($assert): string {
    $baseline = (new UniverseGenerator())->generate('core-ui-qa-seed');
    $assert($baseline['system_count'] === count($baseline['systems']), 'System count does not match systems array.');
    $assert($baseline['system_count'] >= 8 && $baseline['system_count'] <= 24, 'System count is outside expected bounds (8–24).');
    $ids = [];
    foreach ($baseline['systems'] as $system) {
        $assert(isset($system['id'], $system['name'], $system['x'], $system['y'], $system['classification']), 'System missing required fields.');
        $assert(!in_array($system['id'], $ids, true), 'Duplicate system ID.');
        $ids[] = $system['id'];
        $assert($system['x'] >= -10000 && $system['x'] <= 10000 && $system['y'] >= -10000 && $system['y'] <= 10000, 'Coordinates out of bounds.');
    }
    return count($ids) . ' systems checked.';
});
$run('World profiles are deterministic, uniquely identified, and UWP-shaped', static function () use ($assert, $equal): string {
    $generator = new WorldGenerator();
    $system = ['id' => 'sys_browser_world_qa', 'name' => 'Browser QA'];
    $worlds = $generator->generateForSystem('core-ui-world-seed', $system);
    $equal($worlds, $generator->generateForSystem('core-ui-world-seed', $system), 'Repeated world generation changed output.');
    $assert(count($worlds) >= 1 && count($worlds) <= 9, 'Generated world count is outside bounds.');
    $ids = [];
    foreach ($worlds as $world) {
        $assert(strlen((string)($world['uwp'] ?? '')) === 8, 'World UWP is not eight characters.');
        $assert(!in_array($world['id'] ?? null, $ids, true), 'World IDs are not unique.');
        $ids[] = $world['id'];
        $assert(($world['size'] ?? -1) >= 0 && ($world['size'] ?? 99) <= 10, 'World size is out of range.');
        $assert(($world['population'] ?? -1) >= 0 && ($world['population'] ?? 99) <= 10, 'World population is out of range.');
    }
    return count($worlds) . ' stable world profiles generated with unique IDs and valid UWP values.';
});
$run('Gameplay derives worlds at runtime without changing saved universe data', static function () use ($assert): string {
    $game = (string)file_get_contents(dirname(__DIR__) . '/player/game.php');
    $js = (string)file_get_contents(dirname(__DIR__) . '/player/player.js');
    $assert(str_contains($game, 'new \\Core\\Modules\\Universe\\WorldGenerator()'), 'Gameplay does not initialize the deterministic world generator.');
    $assert(str_contains($game, "'universe' => \$playerUniverse"), 'Gameplay does not inject the derived player universe view.');
    $assert(str_contains($js, 'selectedWorldList') && str_contains($js, 'world.uwp'), 'Gameplay does not render selected system world profiles.');
    return 'World profiles are derived for the player view and rendered without a storage migration.';
});

$run('Constellation navigation opens at the character Constellation and restores its parent after System View', static function () use ($assert): string {
    $game = (string)file_get_contents(dirname(__DIR__) . '/player/game.php');
    $client = (string)file_get_contents(dirname(__DIR__) . '/player/player.js');
    foreach (['id="constellationSelect"', 'Constellation View', 'id="constellationSystemList"', 'id="selectedWorldList"', 'Back to Constellation View', 'id="systemViewTitle"'] as $needle) {
        $assert(str_contains($game, $needle), 'Navigation interface is missing ' . $needle . '.');
    }
    foreach (['visibleSystems()', 'state.selectedConstellationId = system.constellation_id', "state.view = 'system'", "state.view='constellation'", 'renderMap();'] as $needle) {
        $assert(str_contains($client, $needle), 'Hierarchical navigation state is missing ' . $needle . '.');
    }
    $assert(!preg_match('/drawSystemView\(boot\.initialSystemId\)/', $client), 'Gameplay must open Constellation View before entering a System.');
    $assert(str_contains($client, 'state.character.active_universe_id || state.character.universe_id'), 'Shared-universe visitors must be validated against their active universe without replacing their home universe ID.');
    $assert(str_contains($client, 'state.selectedConstellationId = currentConstellationId()'), 'Travel must move the Constellation View context to the character current Constellation.');
    return 'Play opens the character Constellation; the System list is scoped to that Constellation; Back restores its Constellation View and Worlds remain in System View.';
});

$run('Create and reload preserve identity and baseline', static function () use ($equal, $assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $first = $service->createOrLoad('core-ui-qa-persistence');
        $second = $service->createOrLoad('core-ui-qa-persistence');
        $equal($first['id'], $second['id'], 'Universe ID changed on reload.');
        $equal($first['created_at'], $second['created_at'], 'Creation timestamp changed on reload.');
        $equal($first['baseline'], $second['baseline'], 'Baseline changed on reload.');
        $assert(is_file($dir . '/universes/' . $first['id'] . '.json'), 'Persistence file was not created.');
        return 'Saved and reloaded in a temporary directory.';
    } finally { $cleanup($dir); }
});
$run('Unsafe storage paths are rejected', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        try { $storage->read('../escape', 'record'); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'Invalid storage path segment.'), 'Unexpected validation exception.');
            return 'Traversal-like collection name rejected.';
        }
        throw new RuntimeException('Unsafe collection name was accepted.');
    } finally { $cleanup($dir); }
});

$run('JSON writes are complete and readable after replacement', static function () use ($equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $record = ['id' => 'record-1', 'payload' => str_repeat('CORE-persistence-', 2048), 'revision' => 1];
        $storage->write('records', 'record-1', $record);
        $equal($record, $storage->read('records', 'record-1'), 'Written record did not round-trip exactly.');
        $record['revision'] = 2;
        $storage->write('records', 'record-1', $record);
        $equal($record, $storage->read('records', 'record-1'), 'Replaced record did not round-trip exactly.');
        return 'Large record and replacement both round-tripped exactly.';
    } finally { $cleanup($dir); }
});
$run('Writes use a per-record lock and leave no temporary files', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $storage->write('records', 'locked-record', ['value' => 'stable']);
        $assert(is_file($dir . '/records/locked-record.json.lock'), 'Per-record lock file was not created.');
        $files = array_values(array_filter(scandir($dir . '/records') ?: [], static fn(string $name): bool => str_starts_with($name, '.core-')));
        $assert($files === [], 'Temporary files were left behind after a successful write.');
        return 'Record lock exists and successful writes leave no temporary files.';
    } finally { $cleanup($dir); }
});
$run('Concurrent-style create attempts preserve the first stored record', static function () use ($equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $first = $storage->createIfAbsent('records', 'shared-id', ['id' => 'shared-id', 'owner' => 'first']);
        $second = $storage->createIfAbsent('records', 'shared-id', ['id' => 'shared-id', 'owner' => 'second']);
        $equal('first', $second['owner'], 'A later create attempt replaced the first record.');
        $equal($first, $storage->read('records', 'shared-id'), 'Stored record changed after a duplicate create attempt.');
        return 'Duplicate create returned the original record without overwriting it.';
    } finally { $cleanup($dir); }
});
$run('Universe state updates enforce revision checks', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-revision');
        $updated = $service->updateState($universe['id'], 0, ['type' => 'qa_change', 'value' => 1]);
        $equal(1, $updated['state']['revision'], 'Revision did not increment.');
        $equal(1, count($updated['state']['changes']), 'Change was not appended.');
        try { $service->updateState($universe['id'], 0, ['type' => 'stale_change']); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'Revision conflict:'), 'Unexpected stale revision error.');
            $reloaded = (new JsonStorage($dir))->read('universes', $universe['id']);
            $equal(1, $reloaded['state']['revision'], 'Stale update modified the revision.');
            $equal(1, count($reloaded['state']['changes']), 'Stale update was applied.');
            return 'Current revision committed; stale revision rejected without changing saved state.';
        }
        throw new RuntimeException('Stale revision was accepted.');
    } finally { $cleanup($dir); }
});

$run('Universe state changes require a type', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-change-type');
        try { $service->updateState($universe['id'], 0, ['value' => 'missing type']); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'non-empty string type'), 'Unexpected validation error.');
            $saved = (new JsonStorage($dir))->read('universes', $universe['id']);
            $assert($saved['state']['revision'] === 0, 'Invalid change modified saved state.');
            return 'Missing change type rejected without modifying the universe.';
        }
        throw new RuntimeException('Change without type was accepted.');
    } finally { $cleanup($dir); }
});

$run('Oversized universe state changes are rejected', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-change-size');
        try { $service->updateState($universe['id'], 0, ['type' => 'oversized', 'payload' => str_repeat('x', 17000)]); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), '16 KB limit'), 'Unexpected size validation error.');
            $saved = (new JsonStorage($dir))->read('universes', $universe['id']);
            $assert($saved['state']['revision'] === 0, 'Oversized change modified saved state.');
            return 'Changes larger than 16 KB rejected without modifying the universe.';
        }
        throw new RuntimeException('Oversized change was accepted.');
    } finally { $cleanup($dir); }
});

$run('State changes are stored as versioned event records', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-event-schema');
        $updated = $service->updateState($universe['id'], 0, ['type' => 'note_added', 'value' => 'hello', 'source' => 'qa']);
        $event = $updated['state']['changes'][0] ?? null;
        $assert(is_array($event), 'No event record was stored.');
        foreach (['schema_version', 'event_id', 'type', 'payload', 'revision', 'recorded_at'] as $field) {
            $assert(array_key_exists($field, $event), 'Event is missing ' . $field . '.');
        }
        $equal(1, $event['schema_version'], 'Unexpected event schema version.');
        $equal('note_added', $event['type'], 'Event type was not normalized.');
        $equal(['value' => 'hello', 'source' => 'qa'], $event['payload'], 'Event payload does not preserve custom fields.');
        $equal(1, $event['revision'], 'Event revision does not match committed revision.');
        $assert(preg_match('/^[a-f0-9]{32}$/', $event['event_id']) === 1, 'Event ID is not a 128-bit hexadecimal ID.');
        $assert(strtotime($event['recorded_at']) !== false, 'Event timestamp is invalid.');
        return 'Stored event has schema version, unique ID, type, payload, revision, and timestamp.';
    } finally { $cleanup($dir); }
});

$run('Invalid event type formats are rejected without mutation', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-event-type');
        try { $service->updateState($universe['id'], 0, ['type' => 'Not Valid!', 'value' => 1]); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'Event type must start'), 'Unexpected invalid event type error.');
            $saved = (new JsonStorage($dir))->read('universes', $universe['id']);
            $assert($saved['state']['revision'] === 0, 'Invalid event changed the revision.');
            $assert($saved['state']['changes'] === [], 'Invalid event was appended.');
            return 'Invalid event type rejected without changing saved state.';
        }
        throw new RuntimeException('Invalid event type was accepted.');
    } finally { $cleanup($dir); }
});

$run('Corrupt JSON is rejected instead of silently accepted', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $collection = $dir . '/records';
        if (!mkdir($collection, 0770, true) && !is_dir($collection)) throw new RuntimeException('Could not prepare QA fixture.');
        file_put_contents($collection . '/broken.json', '{invalid json');
        try { (new JsonStorage($dir))->read('records', 'broken'); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'Stored JSON record is invalid'), 'Unexpected corrupt-record error.');
            return 'Malformed JSON raises an explicit storage error.';
        }
        throw new RuntimeException('Malformed JSON was silently accepted.');
    } finally { $cleanup($dir); }
});

$run('note_added events update the notes projection', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-note-projection');
        $updated = $service->updateState($universe['id'], 0, ['type' => 'note_added', 'value' => 'Hello from QA']);
        $notes = $updated['state']['projections']['notes'] ?? [];
        $equal(1, count($notes), 'Note event did not create one projected note.');
        $equal('Hello from QA', $notes[0]['text'] ?? null, 'Projected note text did not match.');
        $equal(1, $notes[0]['revision'] ?? null, 'Projected note revision did not match.');
        $equal('applied', $updated['state']['event_processing'][0]['status'] ?? null, 'Event processing status was not applied.');
        return 'note_added created a derived note and recorded successful processing.';
    } finally { $cleanup($dir); }
});

$run('Invalid note_added payload aborts the transaction', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-invalid-note');
        try { $service->updateState($universe['id'], 0, ['type' => 'note_added', 'value' => '   ']); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'non-empty text or value string'), 'Unexpected invalid note error.');
            $saved = (new JsonStorage($dir))->read('universes', $universe['id']);
            $equal(0, $saved['state']['revision'], 'Rejected note advanced the revision.');
            $equal([], $saved['state']['changes'], 'Rejected note was appended to event history.');
            $assert(!isset($saved['state']['projections']['notes']), 'Rejected note changed the notes projection.');
            return 'Invalid note payload rejected with no committed state changes.';
        }
        throw new RuntimeException('Empty note payload was accepted.');
    } finally { $cleanup($dir); }
});

$run('Unknown event types are recorded as unhandled', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-unhandled-event');
        $updated = $service->updateState($universe['id'], 0, ['type' => 'exploration_started', 'system_id' => 'system-test']);
        $equal(1, $updated['state']['revision'], 'Unknown but valid event was not recorded.');
        $equal('unhandled', $updated['state']['event_processing'][0]['status'] ?? null, 'Unknown event was not marked unhandled.');
        $assert(count($updated['state']['changes']) === 1, 'Unknown event was not preserved in history.');
        return 'Valid future event preserved in history and explicitly marked unhandled.';
    } finally { $cleanup($dir); }
});


$run('system_explored events add a validated system to the exploration projection', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-exploration-valid');
        $system = $universe['baseline']['systems'][0];
        $updated = $service->updateState($universe['id'], 0, ['type' => 'system_explored', 'system_id' => $system['id']]);
        $explored = $updated['state']['projections']['explored_systems'] ?? [];
        $equal(1, count($explored), 'Exploration projection should contain one system.');
        $equal($system['id'], $explored[0]['system_id'] ?? null, 'Explored system ID did not match.');
        $equal($system['name'], $explored[0]['name'] ?? null, 'Explored system name did not match baseline.');
        $equal('applied', $updated['state']['event_processing'][0]['status'] ?? null, 'Exploration event was not applied.');
        return 'A valid generated system was added to explored_systems with baseline details.';
    } finally { $cleanup($dir); }
});

$run('system_explored rejects system IDs outside the universe without mutation', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-exploration-invalid');
        try { $service->updateState($universe['id'], 0, ['type' => 'system_explored', 'system_id' => 'sys_not_in_this_universe']); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'does not belong to this universe'), 'Unexpected invalid-system error.');
            $saved = (new JsonStorage($dir))->read('universes', $universe['id']);
            $equal(0, $saved['state']['revision'], 'Rejected exploration advanced revision.');
            $equal([], $saved['state']['changes'], 'Rejected exploration was appended to history.');
            $assert(!isset($saved['state']['projections']['explored_systems']), 'Rejected exploration changed projection.');
            return 'Foreign system ID rejected and transaction left the universe unchanged.';
        }
        throw new RuntimeException('Foreign system ID was accepted.');
    } finally { $cleanup($dir); }
});

$run('re-exploring a system does not duplicate its exploration projection', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new UniverseService(new JsonStorage($dir));
        $universe = $service->createOrLoad('core-ui-qa-exploration-duplicate');
        $systemId = $universe['baseline']['systems'][0]['id'];
        $first = $service->updateState($universe['id'], 0, ['type' => 'system_explored', 'system_id' => $systemId]);
        $second = $service->updateState($universe['id'], 1, ['type' => 'system_explored', 'system_id' => $systemId]);
        $equal(1, count($second['state']['projections']['explored_systems'] ?? []), 'Duplicate exploration created duplicate projection entries.');
        $equal(2, count($second['state']['changes'] ?? []), 'Both submitted events should remain in event history.');
        $equal('already_explored', $second['state']['event_processing'][1]['status'] ?? null, 'Repeat exploration status was not explicit.');
        $equal(1, $first['state']['revision'], 'First exploration revision incorrect.');
        $equal(2, $second['state']['revision'], 'Second exploration revision incorrect.');
        return 'Repeated exploration remains in history but does not duplicate the explored-system projection.';
    } finally { $cleanup($dir); }
});

$run('Character creation links a valid character to its universe', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-character-create');
        $character = (new CharacterService($storage))->create($universe['id'], 'Mira Voss', 'Explorer');
        $equal($universe['id'], $character['universe_id'], 'Character linked to the wrong universe.');
        $equal('Mira Voss', $character['name'], 'Character name was not preserved.');
        $equal('Explorer', $character['role'], 'Character role was not preserved.');
        $assert(preg_match('/^chr_[a-f0-9]{24}$/', $character['id']) === 1, 'Character ID format is invalid.');
        $equal(0, $character['revision'], 'New character revision must start at zero.');
        return 'Character record contains a unique ID and valid universe link.';
    } finally { $cleanup($dir); }
});

$run('Character point-buy enforces its budget and applies species ability modifiers', static function () use ($assert, $equal, $cleanup): string {
    $options = \Core\Modules\Characters\CharacterCreationRules::definitions();
    $scores = ['strength'=>12,'dexterity'=>14,'constitution'=>10,'intelligence'=>12,'wisdom'=>10,'charisma'=>11];
    $creation = \Core\Modules\Characters\CharacterCreationRules::validate($options, 'human', $scores, 'wisdom');
    $equal(10, $creation['ability_points_spent'], 'Valid point-buy allocation did not total ten points.');
    $equal(12, $creation['attributes']['wisdom'], 'Human flexible bonus was not applied.');
    $android = \Core\Modules\Characters\CharacterCreationRules::validate($options, 'android', $scores, null);
    $equal(16, $android['attributes']['dexterity'], 'Android Dexterity bonus was not applied.');
    $equal(9, $android['attributes']['charisma'], 'Android Charisma penalty was not applied.');
    try {
        \Core\Modules\Characters\CharacterCreationRules::validate($options, 'human', ['strength'=>16,'dexterity'=>16,'constitution'=>10,'intelligence'=>10,'wisdom'=>10,'charisma'=>10], 'wisdom');
        throw new RuntimeException('Over-budget ability allocation was accepted.');
    } catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'exceed the 10-point budget'), 'Unexpected point-buy validation error.'); }
    return 'Ten-point allocation, human flexible bonus, Android fixed adjustments, and over-budget rejection verified.';
});

$run('Character creation page exposes live point-buy and species adjustment controls', static function () use ($assert): string {
    $page = (string)file_get_contents(dirname(__DIR__) . '/player/character-create.php');
    $script = (string)file_get_contents(dirname(__DIR__) . '/player/character-creation.js');
    $assert(str_contains($page, 'abilityPointsRemaining') && str_contains($page, 'human_bonus_attribute'), 'Point-buy or human bonus controls are missing from the form.');
    $assert(str_contains($page, 'character-creation.js?v=<?=rawurlencode($releaseVersion)?>'), 'Character creation behavior is not cache-versioned from the central release version.');
    $assert(str_contains($page, 'character-preview.js?v=<?=rawurlencode($releaseVersion)?>'), 'Character preview behavior is not cache-versioned from the central release version.');
    $assert(str_contains($page, '$releaseVersion = require $root . \'/config/version.php\';'), 'Character creation page does not load the central release version.');
    $assert(str_contains($script, 'ability_points_spent') || str_contains($script, 'abilityPointsSpent'), 'Live point-buy display is missing.');
    $assert(str_contains($script, 'humanBonusSelect.disabled = !flexible'), 'Hidden human-only choice is not disabled for other species.');
    return 'Character creation exposes point budget, final-score previews, and the flexible human ability choice.';
});

$run('Owned unassigned characters can be safely assigned once to a universe', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-character-assignment-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-character-assignment');
        $character = (new CharacterService($storage))->create('', 'Assignment Pilot', 'explorer', 'human', [], 'qa-account-owner');
        $service = new Core\Modules\Characters\CharacterUniverseAssignmentService($storage);
        $assigned = $service->assign($character['id'], 'qa-account-owner', $universe['id']);
        $saved = $storage->read('characters', $character['id']);
        $equal('assigned', $assigned['_assignment_status'] ?? null, 'Assignment did not report a new association.');
        $equal($universe['id'], $saved['universe_id'] ?? null, 'Character universe association was not saved.');
        $equal($universe['baseline']['systems'][0]['id'], $saved['current_system_id'] ?? null, 'Starting location was not initialized.');
        $equal(1, $saved['revision'] ?? null, 'Assignment revision was not incremented.');
        $before = $saved;
        $repeated = $service->assign($character['id'], 'qa-account-owner', $universe['id']);
        $equal('already_assigned', $repeated['_assignment_status'] ?? null, 'Repeat assignment was not idempotent.');
        $equal($before, $storage->read('characters', $character['id']), 'Repeat assignment modified saved character progress.');
        return 'Account ownership is checked, initial location and revision are committed once, and repeat assignment preserves the character record.';
    } finally { $cleanup($dir); }
});

$run('Character records persist and list only within their universe', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universes = new UniverseService($storage);
        $one = $universes->createOrLoad('core-ui-qa-character-list-one');
        $two = $universes->createOrLoad('core-ui-qa-character-list-two');
        $service = new CharacterService($storage);
        $created = $service->create($one['id'], 'Aster Vale', 'Pilot');
        $service->create($two['id'], 'Niko Renn', 'Industrialist');
        $listed = $service->listForUniverse($one['id']);
        $equal(1, count($listed), 'Universe character list contains an unexpected number of records.');
        $equal($created['id'], $listed[0]['id'], 'Persisted character ID changed.');
        $equal($one['id'], $listed[0]['universe_id'], 'Character from another universe leaked into the list.');
        return 'Character persists and universe-scoped listing excludes other universes.';
    } finally { $cleanup($dir); }
});

$run('Character creation rejects a nonexistent universe', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        try { (new CharacterService($storage))->create('uni_missing', 'Mira Voss'); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'universe does not exist'), 'Unexpected missing-universe error.');
            $equal([], $storage->all('characters'), 'Invalid character was persisted.');
            return 'Unknown universe rejected without creating a character record.';
        }
        throw new RuntimeException('Character was created for a nonexistent universe.');
    } finally { $cleanup($dir); }
});

$run('Character name and role validation rejects invalid records', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-character-validation');
        $service = new CharacterService($storage);
        foreach ([['A', 'Explorer'], ['Valid Name', str_repeat('x', 41)]] as [$name, $role]) {
            try { $service->create($universe['id'], $name, $role); }
            catch (RuntimeException $e) { continue; }
            throw new RuntimeException('Invalid character fields were accepted.');
        }
        $equal([], $storage->all('characters'), 'Invalid character records were persisted.');
        return 'Too-short names and oversized roles are rejected without persistence.';
    } finally { $cleanup($dir); }
});

$run('Character listing rejects an unknown universe', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new CharacterService(new JsonStorage($dir));
        try { $service->listForUniverse('uni_missing'); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'universe does not exist'), 'Unexpected missing-universe error.');
            return 'Character listing requires an existing universe.';
        }
        throw new RuntimeException('Unknown universe listing was accepted.');
    } finally { $cleanup($dir); }
});

$run('New characters start in the universe first system', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-character-start');
        $character = (new CharacterService($storage))->create($universe['id'], 'Location Test');
        $firstSystemId = $universe['baseline']['systems'][0]['id'];
        $equal($firstSystemId, $character['current_system_id'] ?? null, 'Character did not start in the first system.');
        $equal($firstSystemId, $character['location']['system_id'] ?? null, 'Location model does not match current system.');
        return 'Character starts in the first generated system with a location timestamp.';
    } finally { $cleanup($dir); }
});

$run('Character can move to another system in its universe', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-character-move');
        $service = new CharacterService($storage);
        $character = $service->create($universe['id'], 'Mover');
        $graph = NavigationGraph::build($universe['baseline']['systems']);
        $target = $graph['neighbors'][$character['current_system_id']][0];
        $moved = $service->move($universe['id'], $character['id'], $target, 0);
        $equal($target, $moved['current_system_id'] ?? null, 'Current system was not updated.');
        $equal($target, $moved['location']['system_id'] ?? null, 'Location projection was not updated.');
        $equal(1, $moved['revision'], 'Character revision did not increment.');
        $persisted = $moved; unset($persisted['_movement_status']);
        $equal($persisted, $storage->read('characters', $character['id']), 'Moved character was not persisted.');
        return 'Location persisted and character revision advanced from 0 to 1.';
    } finally { $cleanup($dir); }
});

$run('Character cannot move to a system from another universe', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universes = new UniverseService($storage);
        $first = $universes->createOrLoad('core-ui-qa-character-universe-a');
        $second = $universes->createOrLoad('core-ui-qa-character-universe-b');
        $service = new CharacterService($storage);
        $character = $service->create($first['id'], 'Boundary Test');
        try { $service->move($first['id'], $character['id'], $second['baseline']['systems'][0]['id'], 0); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'does not belong'), 'Unexpected cross-universe validation error.');
            $saved = $storage->read('characters', $character['id']);
            $equal($character['current_system_id'], $saved['current_system_id'], 'Rejected move changed character location.');
            $equal(0, $saved['revision'], 'Rejected move advanced character revision.');
            return 'Cross-universe destination rejected without modifying the character.';
        }
        throw new RuntimeException('Cross-universe system was accepted.');
    } finally { $cleanup($dir); }
});

$run('Character movement rejects stale revisions', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-character-stale');
        $service = new CharacterService($storage);
        $character = $service->create($universe['id'], 'Revision Test');
        $systems = $universe['baseline']['systems'];
        $graph = NavigationGraph::build($systems);
        $firstDestination = $graph['neighbors'][$character['current_system_id']][0];
        $service->move($universe['id'], $character['id'], $firstDestination, 0);
        try { $service->move($universe['id'], $character['id'], $systems[2]['id'], 0); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'revision conflict'), 'Unexpected stale revision error.');
            $saved = $storage->read('characters', $character['id']);
            $equal($firstDestination, $saved['current_system_id'], 'Stale move changed the current system.');
            $equal(1, $saved['revision'], 'Stale move changed the revision.');
            return 'Stale character movement rejected without overwriting the newer location.';
        }
        throw new RuntimeException('Stale character movement was accepted.');
    } finally { $cleanup($dir); }
});


$run('Repeating a move to the current system is idempotent', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-idempotent-move');
        $service = new CharacterService($storage);
        $character = $service->create($universe['id'], 'Idempotent Mover');
        $systemId = $character['current_system_id'];
        $result = $service->move($universe['id'], $character['id'], $systemId, 0);
        $equal('already_at_destination', $result['_movement_status'] ?? null, 'Same-system movement status was not explicit.');
        $equal(0, $result['revision'], 'Same-system movement incremented the revision.');
        $saved = $storage->read('characters', $character['id']);
        $equal(0, $saved['revision'], 'Same-system movement changed the saved revision.');
        $assert(!array_key_exists('_movement_status', $saved), 'Internal movement metadata was persisted.');
        return 'Repeated same-destination move returns already_at_destination and leaves revision unchanged.';
    } finally { $cleanup($dir); }
});

$run('Character creation records its starting system as explored', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-start-exploration');
        $character = (new CharacterService($storage))->create($universe['id'], 'Starting Explorer');
        $visited = $character['exploration']['explored_systems'] ?? [];
        $equal(1, count($visited), 'Starting system was not recorded exactly once.');
        $equal($character['current_system_id'], $visited[0]['system_id'] ?? null, 'Starting explored system does not match current location.');
        $assert(isset($visited[0]['first_visited_at'], $visited[0]['first_visited_revision']), 'Starting visit metadata is incomplete.');
        return 'Starting system appears once in character-specific exploration history.';
    } finally { $cleanup($dir); }
});

$run('Moving to a new system adds it to character exploration history', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-exploration-history');
        $service = new CharacterService($storage);
        $character = $service->create($universe['id'], 'History Explorer');
        $graph = NavigationGraph::build($universe['baseline']['systems']);
        $targetId = $graph['neighbors'][$character['current_system_id']][0];
        $target = array_values(array_filter($universe['baseline']['systems'], static fn(array $system): bool => $system['id'] === $targetId))[0];
        $moved = $service->move($universe['id'], $character['id'], $target['id'], 0);
        $visited = $moved['exploration']['explored_systems'] ?? [];
        $equal(2, count($visited), 'Exploration history should contain the start and destination systems.');
        $equal($target['id'], $visited[1]['system_id'] ?? null, 'Destination was not added to exploration history.');
        $equal($target['name'], $visited[1]['name'] ?? null, 'Exploration entry did not capture the system name.');
        $equal(1, $visited[1]['first_visited_revision'] ?? null, 'Exploration entry has incorrect first-visit revision.');
        return 'Moving to a new system records its ID, name, timestamp, and first-visit revision.';
    } finally { $cleanup($dir); }
});

$run('Returning to an explored system does not duplicate exploration history', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-exploration-dedup');
        $service = new CharacterService($storage);
        $character = $service->create($universe['id'], 'Returning Explorer');
        $systems = $universe['baseline']['systems'];
        $graph = NavigationGraph::build($systems);
        $startId = $character['current_system_id'];
        $neighborId = $graph['neighbors'][$startId][0];
        $firstMove = $service->move($universe['id'], $character['id'], $neighborId, 0);
        $back = $service->move($universe['id'], $character['id'], $startId, 1);
        $equal(2, count($back['exploration']['explored_systems'] ?? []), 'Returning to the starting system created a duplicate entry.');
        $equal(2, $back['revision'], 'Returning to a previously explored system did not advance movement revision.');
        $equal($firstMove['exploration']['explored_systems'][0]['first_visited_at'], $back['exploration']['explored_systems'][0]['first_visited_at'], 'Original first-visit timestamp changed.');
        return 'Returning to a known system changes location but keeps one stable first-visit record per system.';
    } finally { $cleanup($dir); }
});

$run('Navigation graph connects every generated system', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $universe = (new UniverseService(new JsonStorage($dir)))->createOrLoad('core-ui-qa-navigation-connected');
        $systems = $universe['baseline']['systems'];
        $graph = NavigationGraph::build($systems);
        $equal(count($systems) - 1, count($graph['routes']), 'MST should contain N-1 routes.');
        $seen = []; $queue = [$systems[0]['id']];
        while ($queue) { $id = array_shift($queue); if (isset($seen[$id])) continue; $seen[$id] = true; foreach ($graph['neighbors'][$id] ?? [] as $next) if (!isset($seen[$next])) $queue[] = $next; }
        $equal(count($systems), count($seen), 'Navigation graph is not fully connected.');
        return count($systems) . ' systems connected by ' . count($graph['routes']) . ' deterministic routes.';
    } finally { $cleanup($dir); }
});
$run('Navigation graph generation is deterministic', static function () use ($equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try { $universe = (new UniverseService(new JsonStorage($dir)))->createOrLoad('core-ui-qa-navigation-deterministic'); $systems = $universe['baseline']['systems']; $equal(NavigationGraph::build($systems), NavigationGraph::build($systems), 'Graph output changed for same systems.'); return 'Repeated graph generation matched exactly.'; }
    finally { $cleanup($dir); }
});
$run('Character can move to a directly connected system only', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-navigation-move'); $service = new CharacterService($storage); $character = $service->create($universe['id'], 'Route Mover'); $graph = NavigationGraph::build($universe['baseline']['systems']); $neighbor = $graph['neighbors'][$character['current_system_id']][0]; $moved = $service->move($universe['id'], $character['id'], $neighbor, 0); $equal($neighbor, $moved['current_system_id'], 'Connected movement failed.'); $equal(1, $moved['revision'], 'Connected movement revision incorrect.'); return 'Connected neighbor accepted and revision advanced.';
    } finally { $cleanup($dir); }
});
$run('Character cannot jump across a route without a direct connection', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-navigation-block'); $service = new CharacterService($storage); $character = $service->create($universe['id'], 'No Jump'); $graph = NavigationGraph::build($universe['baseline']['systems']); $neighbors = $graph['neighbors'][$character['current_system_id']]; $nonNeighbor = null; foreach ($universe['baseline']['systems'] as $system) if ($system['id'] !== $character['current_system_id'] && !in_array($system['id'], $neighbors, true)) { $nonNeighbor = $system['id']; break; } if ($nonNeighbor === null) throw new RuntimeException('Fixture unexpectedly has no non-neighbor system.');
        try { $service->move($universe['id'], $character['id'], $nonNeighbor, 0); } catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'not directly reachable'), 'Unexpected route validation error.'); $saved = $storage->read('characters', $character['id']); $equal($character['current_system_id'], $saved['current_system_id'], 'Rejected jump changed location.'); $equal(0, $saved['revision'], 'Rejected jump advanced revision.'); return 'Unconnected destination rejected without changing character state.'; } throw new RuntimeException('Unconnected destination was accepted.');
    } finally { $cleanup($dir); }
});

$run('Shortest route includes both endpoints and valid connected hops', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $universe = (new UniverseService(new JsonStorage($dir)))->createOrLoad('core-ui-qa-shortest-route');
        $systems = $universe['baseline']['systems'];
        $graph = NavigationGraph::build($systems);
        $from = $systems[0]['id']; $to = $systems[count($systems) - 1]['id'];
        $path = NavigationGraph::shortestPath($graph, $from, $to);
        $equal($from, $path[0] ?? null, 'Route does not start at the requested system.');
        $equal($to, $path[count($path) - 1] ?? null, 'Route does not end at the requested system.');
        for ($i = 1; $i < count($path); $i++) $assert(in_array($path[$i], $graph['neighbors'][$path[$i - 1]] ?? [], true), 'Route contains a non-connected hop.');
        return count($path) - 1 . ' connected hop(s) returned from start to destination.';
    } finally { $cleanup($dir); }
});
$run('Route service plans between two valid saved systems', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-route-service-integration');
        $systems = $universe['baseline']['systems'];
        if (count($systems) < 2) throw new RuntimeException('Fixture needs at least two generated systems.');
        $from = (string)$systems[0]['id'];
        $to = (string)$systems[count($systems) - 1]['id'];
        $result = (new NavigationRouteService($storage))->plan($universe['id'], $from, $to);
        $equal(true, $result['ok'] ?? false, 'Route service did not report success.');
        $equal($from, $result['from_system_id'] ?? null, 'Route service returned the wrong start system.');
        $equal($to, $result['to_system_id'] ?? null, 'Route service returned the wrong destination system.');
        $path = $result['path'] ?? [];
        $assert(count($path) >= 2, 'Route between different valid systems must contain at least two path entries.');
        $equal($from, $path[0]['system_id'] ?? null, 'Route path does not begin at the requested system.');
        $equal($to, $path[count($path) - 1]['system_id'] ?? null, 'Route path does not end at the requested system.');
        $equal(count($path) - 1, $result['hops'] ?? null, 'Hop count does not match path length.');
        $graph = NavigationGraph::build($systems);
        for ($i = 1; $i < count($path); $i++) {
            $previousId = $path[$i - 1]['system_id'] ?? '';
            $nextId = $path[$i]['system_id'] ?? '';
            $assert(in_array($nextId, $graph['neighbors'][$previousId] ?? [], true), 'Route service returned a hop that is not connected.');
        }
        return 'Shared route-planning service returned a valid multi-system route between two saved, valid system IDs.';
    } finally { $cleanup($dir); }
});

$run('Route planning from a system to itself returns zero hops', static function () use ($equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $universe = (new UniverseService(new JsonStorage($dir)))->createOrLoad('core-ui-qa-zero-hop-route');
        $graph = NavigationGraph::build($universe['baseline']['systems']);
        $systemId = $universe['baseline']['systems'][0]['id'];
        $equal([$systemId], NavigationGraph::shortestPath($graph, $systemId, $systemId), 'Same-system route should contain one node.');
        return 'Same-system route contains one endpoint and zero hops.';
    } finally { $cleanup($dir); }
});
$run('Route planner rejects system IDs outside the graph', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $universe = (new UniverseService(new JsonStorage($dir)))->createOrLoad('core-ui-qa-invalid-route-endpoint');
        $graph = NavigationGraph::build($universe['baseline']['systems']);
        try { NavigationGraph::shortestPath($graph, $universe['baseline']['systems'][0]['id'], 'sys_not_in_graph'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'endpoints'), 'Unexpected invalid route error.'); return 'Unknown destination rejected by route planner.'; }
        throw new RuntimeException('Unknown route destination was accepted.');
    } finally { $cleanup($dir); }
});


$run('Starting travel stores a route without moving the character', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-travel-start');
        $systems = $universe['baseline']['systems']; $graph = NavigationGraph::build($systems);
        $character = (new CharacterService($storage))->create($universe['id'], 'Travel Starter');
        $from = $character['current_system_id']; $destination = null; $path = [];
        foreach ($systems as $system) { $candidate = NavigationGraph::shortestPath($graph, $from, (string)$system['id']); if (count($candidate) > count($path)) { $path = $candidate; $destination = (string)$system['id']; } }
        $assert(count($path) >= 3, 'Fixture needs a destination at least two jumps away.');
        $result = (new CharacterTravelService($storage))->start($universe['id'], $character['id'], $destination, 0);
        $equal('route_started', $result['travel_status'], 'Travel route did not start.');
        $equal($from, $result['character']['current_system_id'], 'Starting travel moved the character immediately.');
        $equal(1, $result['character']['revision'], 'Starting travel should advance the character revision.');
        $equal($path, $result['character']['route_progress']['path_system_ids'], 'Stored route does not match the shortest path.');
        $equal('active', $result['character']['route_progress']['status'], 'Multi-hop route should be active.');
        return (count($path) - 1) . ' hop route saved; character remained at the starting system.';
    } finally { $cleanup($dir); }
});

$run('Travel next jump advances exactly one hop and records exploration', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-travel-one-hop');
        $systems = $universe['baseline']['systems']; $graph = NavigationGraph::build($systems); $characterService = new CharacterService($storage);
        $character = $characterService->create($universe['id'], 'One Hop'); $from = $character['current_system_id']; $path = [];
        foreach ($systems as $system) { $candidate = NavigationGraph::shortestPath($graph, $from, (string)$system['id']); if (count($candidate) > count($path)) $path = $candidate; }
        $assert(count($path) >= 3, 'Fixture needs a route of at least two hops.');
        $travel = new CharacterTravelService($storage); $started = $travel->start($universe['id'], $character['id'], (string)end($path), 0);
        $advanced = $travel->advance($universe['id'], $character['id'], $started['character']['revision']);
        $equal($path[1], $advanced['character']['current_system_id'], 'One action did not move exactly to the next system.');
        $equal(2, $advanced['character']['revision'], 'One jump should advance revision exactly once after route start.');
        $equal(1, $advanced['character']['route_progress']['current_step_index'], 'Route progress index did not advance by one.');
        $visited = array_column($advanced['character']['exploration']['explored_systems'], 'system_id');
        $assert(in_array($path[1], $visited, true), 'Destination system was not added to exploration history.');
        $equal(count($visited), count(array_unique($visited)), 'Exploration history contains duplicate systems.');
        return 'Exactly one jump executed; revision and exploration history updated.';
    } finally { $cleanup($dir); }
});

$run('Travel completes at the planned destination and cannot advance again', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-travel-complete');
        $systems = $universe['baseline']['systems']; $graph = NavigationGraph::build($systems); $character = (new CharacterService($storage))->create($universe['id'], 'Route Finisher');
        $path = []; foreach ($systems as $system) { $candidate = NavigationGraph::shortestPath($graph, $character['current_system_id'], (string)$system['id']); if (count($candidate) > count($path)) $path = $candidate; }
        $assert(count($path) >= 3, 'Fixture needs a route of at least two hops.'); $destination = (string)end($path); $travel = new CharacterTravelService($storage);
        $result = $travel->start($universe['id'], $character['id'], $destination, 0); $current = $result['character']; $iterations = 0;
        while (($current['route_progress']['status'] ?? '') === 'active' && $iterations < 20) { $result = $travel->advance($universe['id'], $character['id'], (int)$current['revision']); $current = $result['character']; $iterations++; }
        $equal('completed', $current['route_progress']['status'] ?? null, 'Route did not reach completed status.');
        $equal($destination, $current['current_system_id'], 'Character did not reach the selected destination.');
        $equal('route_completed', $result['travel_status'], 'Final jump did not return route_completed.');
        $revision = $current['revision'];
        try { $travel->advance($universe['id'], $character['id'], $revision); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'not active'), 'Unexpected completed-route rejection.'); $saved = $storage->read('characters', $character['id']); $equal($revision, $saved['revision'], 'Rejected advance changed revision.'); $equal($destination, $saved['current_system_id'], 'Rejected advance changed location.'); return $iterations . ' jump(s) completed; completed route cannot be replayed.'; }
        throw new RuntimeException('Completed route accepted another jump.');
    } finally { $cleanup($dir); }
});

$run('Travel rejects stale revisions without moving the character', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-travel-stale'); $systems = $universe['baseline']['systems']; $graph = NavigationGraph::build($systems);
        $character = (new CharacterService($storage))->create($universe['id'], 'Stale Traveller'); $path = [];
        foreach ($systems as $system) { $candidate = NavigationGraph::shortestPath($graph, $character['current_system_id'], (string)$system['id']); if (count($candidate) > count($path)) $path = $candidate; }
        $travel = new CharacterTravelService($storage); $started = $travel->start($universe['id'], $character['id'], (string)end($path), 0); $before = $started['character'];
        try { $travel->advance($universe['id'], $character['id'], 0); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'revision conflict'), 'Unexpected stale-revision error.'); $saved = $storage->read('characters', $character['id']); $equal($before['current_system_id'], $saved['current_system_id'], 'Stale request moved the character.'); $equal($before['revision'], $saved['revision'], 'Stale request changed revision.'); return 'Stale jump rejected without changing location or revision.'; }
        throw new RuntimeException('Stale travel revision was accepted.');
    } finally { $cleanup($dir); }
});

$run('Travel rejects a route after manual movement changes the route origin', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-travel-desync'); $systems = $universe['baseline']['systems']; $graph = NavigationGraph::build($systems); $characters = new CharacterService($storage);
        $character = $characters->create($universe['id'], 'Route Desync'); $path = [];
        foreach ($systems as $system) { $candidate = NavigationGraph::shortestPath($graph, $character['current_system_id'], (string)$system['id']); if (count($candidate) > count($path)) $path = $candidate; }
        $travel = new CharacterTravelService($storage); $started = $travel->start($universe['id'], $character['id'], (string)end($path), 0);
        $characters->move($universe['id'], $character['id'], (string)$path[1], (int)$started['character']['revision']);
        $afterManualMove = $storage->read('characters', $character['id']);
        try { $travel->advance($universe['id'], $character['id'], (int)$afterManualMove['revision']); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'not active'), 'Unexpected route desynchronization error.'); $saved = $storage->read('characters', $character['id']); $equal($afterManualMove['current_system_id'], $saved['current_system_id'], 'Rejected stale route changed location.'); $equal($afterManualMove['revision'], $saved['revision'], 'Rejected stale route changed revision.'); $equal('cancelled', $saved['route_progress']['status'] ?? null, 'Manual movement did not cancel the old route.'); return 'Manual movement cancels the previous route and it cannot be resumed.'; }
        throw new RuntimeException('Out-of-sync route was allowed to continue.');
    } finally { $cleanup($dir); }
});

$run('System scan persists deterministic discoveries and increments revision once', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-scan-persistence');
        $character = (new CharacterService($storage))->create($universe['id'], 'Signal Seeker');
        $scanner = new CharacterScanService($storage); $first = $scanner->scanCurrentSystem($universe['id'], $character['id'], 0);
        $equal('scanned', $first['scan_status'], 'First scan did not report scanned status.');
        $assert(count($first['scan']['discoveries'] ?? []) >= 1 && count($first['scan']['discoveries']) <= 3, 'Discovery count outside expected range.');
        $equal(1, $first['character']['revision'], 'First scan did not increment character revision.');
        $saved = $storage->read('characters', $character['id']);
        $equal($first['scan'], $saved['scans']['systems'][$character['current_system_id']] ?? null, 'Scan results were not persisted.');
        return count($first['scan']['discoveries']) . ' deterministic discovery signal(s) persisted on the character record.';
    } finally { $cleanup($dir); }
});

$run('Repeated scan is idempotent and returns saved results', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-scan-repeat');
        $character = (new CharacterService($storage))->create($universe['id'], 'Repeat Scanner'); $scanner = new CharacterScanService($storage);
        $first = $scanner->scanCurrentSystem($universe['id'], $character['id'], 0);
        $second = $scanner->scanCurrentSystem($universe['id'], $character['id'], 1);
        $equal('already_scanned', $second['scan_status'], 'Repeat scan did not identify an existing scan.');
        $equal($first['scan'], $second['scan'], 'Repeat scan did not return the original discoveries.');
        $equal(1, $second['character']['revision'], 'Repeat scan unexpectedly incremented character revision.');
        return 'Repeated scan returned identical saved discoveries without advancing revision.';
    } finally { $cleanup($dir); }
});

$run('System scanning rejects stale revisions and characters from other universes', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universes = new UniverseService($storage);
        $one = $universes->createOrLoad('core-ui-qa-scan-universe-one'); $two = $universes->createOrLoad('core-ui-qa-scan-universe-two');
        $character = (new CharacterService($storage))->create($one['id'], 'Revision Guard'); $scanner = new CharacterScanService($storage);
        try { $scanner->scanCurrentSystem($one['id'], $character['id'], 4); throw new RuntimeException('Stale scan revision was accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'revision conflict'), 'Unexpected stale revision error.'); }
        try { $scanner->scanCurrentSystem($two['id'], $character['id'], 0); throw new RuntimeException('Cross-universe scan was accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'does not belong'), 'Unexpected cross-universe error.'); }
        $saved = $storage->read('characters', $character['id']);
        $equal(0, $saved['revision'], 'Rejected scan changed revision.');
        $assert(empty($saved['scans']['systems']), 'Rejected scan wrote discovery data.');
        return 'Stale revision and cross-universe scans rejected without persistence changes.';
    } finally { $cleanup($dir); }
});

$run('Discovery investigation persists a result and increments character revision', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-discovery-investigate');
        $character = (new CharacterService($storage))->create($universe['id'], 'Signal Investigator');
        $scan = (new CharacterScanService($storage))->scanCurrentSystem($universe['id'], $character['id'], 0);
        $discovery = $scan['scan']['discoveries'][0];
        $result = (new CharacterDiscoveryService($storage))->investigate($universe['id'], $character['id'], $discovery['id'], 1);
        $equal('investigated', $result['investigation_status'], 'Investigation status mismatch.');
        $equal('investigated', $result['discovery']['status'] ?? null, 'Discovery status was not persisted.');
        $assert(!empty($result['discovery']['outcome']), 'Investigation outcome missing.');
        $equal(2, $result['character']['revision'], 'Investigation did not increment revision once.');
        $saved = $storage->read('characters', $character['id']);
        $savedDiscovery = $saved['scans']['systems'][$character['current_system_id']]['discoveries'][0] ?? null;
        $equal($result['discovery'], $savedDiscovery, 'Investigated discovery not saved in character record.');
        return 'Investigation status, timestamp, outcome, and revision were persisted.';
    } finally { $cleanup($dir); }
});

$run('Repeated discovery investigation is idempotent', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-discovery-repeat');
        $character = (new CharacterService($storage))->create($universe['id'], 'Repeat Investigator');
        $scan = (new CharacterScanService($storage))->scanCurrentSystem($universe['id'], $character['id'], 0);
        $service = new CharacterDiscoveryService($storage); $id = $scan['scan']['discoveries'][0]['id'];
        $first = $service->investigate($universe['id'], $character['id'], $id, 1);
        $second = $service->investigate($universe['id'], $character['id'], $id, 2);
        $equal('already_investigated', $second['investigation_status'], 'Repeat investigation status mismatch.');
        $equal($first['discovery']['outcome'], $second['discovery']['outcome'], 'Repeat investigation changed the outcome.');
        $equal(2, $second['character']['revision'], 'Repeat investigation advanced revision.');
        return 'Repeat investigation returned the saved outcome without changing revision.';
    } finally { $cleanup($dir); }
});

$run('Discovery investigation requires the character to be in the discovery system', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-discovery-location');
        $characters = new CharacterService($storage); $character = $characters->create($universe['id'], 'Remote Investigator');
        $scan = (new CharacterScanService($storage))->scanCurrentSystem($universe['id'], $character['id'], 0);
        $discovery = $scan['scan']['discoveries'][0]; $systems = $universe['baseline']['systems']; $graph = NavigationGraph::build($systems); $path = [];
        foreach ($systems as $system) { $candidate = NavigationGraph::shortestPath($graph, $character['current_system_id'], (string)$system['id']); if (count($candidate) > count($path)) $path = $candidate; }
        $assert(count($path) > 1, 'No alternate system available in generated navigation graph.');
        $moved = $characters->move($universe['id'], $character['id'], (string)$path[1], 1);
        try { (new CharacterDiscoveryService($storage))->investigate($universe['id'], $character['id'], $discovery['id'], $moved['revision']); }
        catch (RuntimeException $e) {
            $assert(str_contains($e->getMessage(), 'Travel to the discovery'), 'Unexpected location error.');
            $saved = $storage->read('characters', $character['id']);
            $equal(2, $saved['revision'], 'Rejected remote investigation changed revision.');
            return 'Remote investigation rejected without changing the saved character.';
        }
        throw new RuntimeException('Discovery was investigated from another system.');
    } finally { $cleanup($dir); }
});

$run('Discovery investigation rejects stale revisions and cross-universe characters', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universes = new UniverseService($storage);
        $one = $universes->createOrLoad('core-ui-qa-discovery-universe-one'); $two = $universes->createOrLoad('core-ui-qa-discovery-universe-two');
        $character = (new CharacterService($storage))->create($one['id'], 'Revision Investigator');
        $scan = (new CharacterScanService($storage))->scanCurrentSystem($one['id'], $character['id'], 0); $id = $scan['scan']['discoveries'][0]['id'];
        $service = new CharacterDiscoveryService($storage);
        try { $service->investigate($one['id'], $character['id'], $id, 0); throw new RuntimeException('Stale revision accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'revision conflict'), 'Unexpected stale revision error.'); }
        try { $service->investigate($two['id'], $character['id'], $id, 1); throw new RuntimeException('Cross-universe investigation accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'does not belong'), 'Unexpected cross-universe error.'); }
        $saved = $storage->read('characters', $character['id']);
        $equal(1, $saved['revision'], 'Rejected requests changed revision.');
        $equal('uninvestigated', $saved['scans']['systems'][$character['current_system_id']]['discoveries'][0]['status'] ?? 'uninvestigated', 'Rejected request changed discovery state.');
        return 'Stale and cross-universe requests rejected without discovery-state changes.';
    } finally { $cleanup($dir); }
});

$run('Investigating a signal awards and persists a typed inventory reward', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-reward-persist');
        $character = (new CharacterService($storage))->create($universe['id'], 'Reward Collector');
        $scan = (new CharacterScanService($storage))->scanCurrentSystem($universe['id'], $character['id'], 0);
        $discovery = $scan['scan']['discoveries'][0];
        $characterRecord = $storage->read('characters', $character['id']);
        $characterRecord['scans']['systems'][$character['current_system_id']]['discoveries'][0]['type'] = 'mineral_signature';
        $storage->write('characters', $character['id'], $characterRecord);
        $result = (new CharacterDiscoveryService($storage))->investigate($universe['id'], $character['id'], $discovery['id'], 1);
        $reward = $result['reward'] ?? [];
        $equal('raw_ore', $reward['resource'] ?? null, 'Mineral signal did not reward raw ore.');
        $assert(($reward['quantity'] ?? 0) >= 2 && $reward['quantity'] <= 5, 'Raw ore reward quantity is out of range.');
        $equal($reward['quantity'], $result['character']['inventory']['resources']['raw_ore'] ?? null, 'Inventory total does not match awarded quantity.');
        $equal(1, count($result['character']['inventory']['ledger'] ?? []), 'Inventory ledger entry was not recorded.');
        $equal($discovery['id'], $result['character']['inventory']['ledger'][0]['discovery_id'] ?? null, 'Ledger entry is not linked to its discovery.');
        $saved = $storage->read('characters', $character['id']);
        $equal($result['character']['inventory'], $saved['inventory'] ?? null, 'Inventory was not persisted.');
        return 'A mineral investigation awards 2–5 raw ore and persists its total and linked ledger entry.';
    } finally { $cleanup($dir); }
});

$run('Repeating an investigation never duplicates inventory rewards', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-reward-idempotent');
        $character = (new CharacterService($storage))->create($universe['id'], 'Idempotent Collector');
        $scan = (new CharacterScanService($storage))->scanCurrentSystem($universe['id'], $character['id'], 0);
        $id = $scan['scan']['discoveries'][0]['id']; $service = new CharacterDiscoveryService($storage);
        $first = $service->investigate($universe['id'], $character['id'], $id, 1);
        $second = $service->investigate($universe['id'], $character['id'], $id, 2);
        $equal('already_investigated', $second['investigation_status'], 'Repeat investigation was not identified.');
        $equal($first['reward'], $second['reward'], 'Repeat investigation reward differs from original.');
        $equal($first['character']['inventory'], $second['character']['inventory'], 'Repeat investigation changed inventory.');
        $equal(1, count($second['character']['inventory']['ledger'] ?? []), 'Repeat investigation added another ledger entry.');
        $equal(2, $second['character']['revision'], 'Repeat investigation advanced revision.');
        return 'Repeated investigation returns the original reward without increasing inventory, ledger count, or revision.';
    } finally { $cleanup($dir); }
});

$run('Different discovery types award their corresponding resource categories', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-reward-types');
        $character = (new CharacterService($storage))->create($universe['id'], 'Multi-resource Collector');
        $scan = (new CharacterScanService($storage))->scanCurrentSystem($universe['id'], $character['id'], 0);
        $record = $storage->read('characters', $character['id']);
        $first = $record['scans']['systems'][$character['current_system_id']]['discoveries'][0];
        $record['scans']['systems'][$character['current_system_id']]['discoveries'][0]['type'] = 'derelict_signal';
        $second = $first; $second['id'] = 'dsc_qa_rare_asteroid'; $second['type'] = 'unusual_asteroid'; $second['label'] = 'QA unusual asteroid';
        $record['scans']['systems'][$character['current_system_id']]['discoveries'][] = $second;
        $storage->write('characters', $character['id'], $record);
        $service = new CharacterDiscoveryService($storage);
        $one = $service->investigate($universe['id'], $character['id'], $first['id'], 1);
        $two = $service->investigate($universe['id'], $character['id'], $second['id'], 2);
        $equal('salvage_parts', $one['reward']['resource'] ?? null, 'Derelict signal reward type mismatch.');
        $equal('rare_ore', $two['reward']['resource'] ?? null, 'Unusual asteroid reward type mismatch.');
        $assert(($two['character']['inventory']['resources']['salvage_parts'] ?? 0) > 0, 'Salvage parts missing from inventory.');
        $assert(($two['character']['inventory']['resources']['rare_ore'] ?? 0) > 0, 'Rare ore missing from inventory.');
        $equal(2, count($two['character']['inventory']['ledger'] ?? []), 'Both recovery events should appear in the ledger.');
        return 'Derelict signals award salvage parts and unusual asteroids award rare ore; both are accumulated separately.';
    } finally { $cleanup($dir); }
});

$run('Crafting consumes materials, creates output, and increments revision', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-crafting-success');
        $character = (new CharacterService($storage))->create($universe['id'], 'Workshop Tester');
        $record = $storage->read('characters', $character['id']);
        $record['inventory'] = ['resources' => ['raw_ore' => 7], 'ledger' => []]; $storage->write('characters', $character['id'], $record);
        $result = (new CharacterCraftingService($storage))->craft($universe['id'], $character['id'], 'refine_ore', 2, 0);
        $equal(1, $result['character']['inventory']['resources']['raw_ore'], 'Raw ore was not consumed at the recipe rate.');
        $equal(2, $result['character']['inventory']['resources']['refined_alloy'], 'Crafted output total is incorrect.');
        $equal(1, $result['character']['revision'], 'Successful craft did not increment revision exactly once.');
        $equal(2, count($result['character']['inventory']['ledger']), 'Craft input/output ledger entries were not written.');
        $equal($result['character']['inventory'], $storage->read('characters', $character['id'])['inventory'], 'Crafted inventory did not persist.');
        return 'Two batches consumed six raw ore, produced two refined alloy, and persisted matching input/output ledger entries.';
    } finally { $cleanup($dir); }
});

$run('Crafting rejects insufficient materials without changing inventory', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-crafting-insufficient');
        $character = (new CharacterService($storage))->create($universe['id'], 'Short on Ore');
        $record = $storage->read('characters', $character['id']); $record['inventory'] = ['resources' => ['raw_ore' => 2], 'ledger' => []]; $storage->write('characters', $character['id'], $record);
        try { (new CharacterCraftingService($storage))->craft($universe['id'], $character['id'], 'refine_ore', 1, 0); }
        catch (RuntimeException $e) {
            $assert(str_contains(strtolower($e->getMessage()), 'insufficient raw ore'), 'Unexpected insufficient-material error.');
            $saved = $storage->read('characters', $character['id']);
            $equal(2, $saved['inventory']['resources']['raw_ore'], 'Rejected craft consumed raw ore.');
            $equal(0, $saved['revision'], 'Rejected craft changed revision.');
            $equal([], $saved['inventory']['ledger'], 'Rejected craft wrote ledger entries.');
            return 'Insufficient input rejected atomically; inventory, ledger, and revision remained unchanged.';
        }
        throw new RuntimeException('Crafting succeeded without enough materials.');
    } finally { $cleanup($dir); }
});

$run('Crafting rejects stale revisions and invalid quantities', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-crafting-revision');
        $character = (new CharacterService($storage))->create($universe['id'], 'Revision Crafter');
        $record = $storage->read('characters', $character['id']); $record['inventory'] = ['resources' => ['salvage_parts' => 4], 'ledger' => []]; $storage->write('characters', $character['id'], $record);
        try { (new CharacterCraftingService($storage))->craft($universe['id'], $character['id'], 'assemble_components', 1, 4); throw new RuntimeException('Stale crafting revision accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'revision conflict'), 'Unexpected stale revision error.'); }
        try { (new CharacterCraftingService($storage))->craft($universe['id'], $character['id'], 'assemble_components', 11, 0); throw new RuntimeException('Invalid craft quantity accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'between 1 and 10'), 'Unexpected quantity validation error.'); }
        $saved = $storage->read('characters', $character['id']);
        $equal(4, $saved['inventory']['resources']['salvage_parts'], 'Rejected crafting changed materials.');
        $equal(0, $saved['revision'], 'Rejected crafting changed revision.');
        return 'Stale revision and out-of-range batch quantity were rejected without changing saved state.';
    } finally { $cleanup($dir); }
});

$run('Workbench exposes crafting recipes, quantity controls, and result handling', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach (['craftRecipe','craftQuantity','craftButton','craftStatus','api/character-craft.php','api/content-recipes.php','api/content-items.php','gameContent.recipes','loadGameContent','Crafting completed'] as $needle) {
        $assert(str_contains($html, $needle), 'Workbench is missing crafting marker: ' . $needle);
    }
    return 'Workbench contains recipe selection, bounded batch input, crafting action, status, and saved result refresh wiring.';
});

$run('Workbench displays character inventory totals and investigation reward details', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach (['characterInventory','Recovered resources','Recorded recovery events:','Reward: +','data.reward?.quantity','inventory.ledger'] as $needle) {
        $assert(str_contains($html, $needle), 'Workbench is missing inventory/reward marker: ' . $needle);
    }
    return 'Inventory totals, ledger event count, and per-discovery reward feedback are wired into the UI.';
});

$run('Workbench exposes investigation actions and result rendering', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach (['investigate-discovery', 'api/character-discovery-investigate.php', 'investigation_status', 'Investigation result:', 'characterScanResults\').addEventListener(\'click\''] as $needle) {
        $assert(str_contains($html, $needle), 'Workbench is missing discovery-investigation marker: ' . $needle);
    }
    return 'Saved signals expose investigation controls and display persistent investigation outcomes.';
});

$run('Workbench exposes accessible system-scan controls and saved discovery rendering', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach (['scanSystemButton','characterScanStatus','characterScanResults','api/character-scan.php','already_scanned'] as $needle) {
        $assert(str_contains($html, $needle), 'Workbench is missing scan feature marker: ' . $needle);
    }
    return 'Scan action, status region, result rendering, and repeat-scan feedback are wired into the Workbench.';
});

$run('Character dashboard exposes status, travel, and distinct exploration summaries', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach (['dashboardCharacter','dashboardLocation','dashboardRevision','dashboardTravelStatus','dashboardTravelDetail','dashboardExploration','dashboardVisitedList','dashboardGlobalList','renderCharacterDashboard'] as $needle) {
        $assert(str_contains($html, $needle), 'Dashboard is missing required field or renderer: ' . $needle);
    }
    $assert(str_contains($html, 'updateCharacterDetails();') && str_contains($html, 'populateCharacterChoices();'), 'Dashboard is not connected to character selection refresh.');
    return 'Dashboard status fields and character-selection refresh hooks are present.';
});

$run('Dashboard source data changes after movement, travel completion, and global exploration', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir);
        $universes = new UniverseService($storage);
        $universe = $universes->createOrLoad('core-ui-qa-dashboard-data');
        $systems = $universe['baseline']['systems'];
        $graph = NavigationGraph::build($systems);
        $characters = new CharacterService($storage);
        $character = $characters->create($universe['id'], 'Dashboard Explorer');
        $from = $character['current_system_id'];
        $longestPath = [];
        foreach ($systems as $system) {
            $candidate = NavigationGraph::shortestPath($graph, $from, (string)$system['id']);
            if (count($candidate) > count($longestPath)) $longestPath = $candidate;
        }
        $assert(count($longestPath) >= 3, 'Dashboard fixture needs a route of at least two hops.');
        $firstDestination = (string)$longestPath[1];
        $moved = $characters->move($universe['id'], $character['id'], $firstDestination, 0);
        $visitedIds = array_column($moved['exploration']['explored_systems'], 'system_id');
        $assert(in_array($firstDestination, $visitedIds, true), 'Movement did not update character exploration data.');
        $equal(1, $moved['revision'], 'Movement revision not reflected in dashboard source data.');

        $travel = new CharacterTravelService($storage);
        $fresh = $storage->read('characters', $character['id']);
        $route = [];
        foreach ($systems as $system) {
            $candidate = NavigationGraph::shortestPath($graph, $fresh['current_system_id'], (string)$system['id']);
            if (count($candidate) > count($route)) $route = $candidate;
        }
        $started = $travel->start($universe['id'], $character['id'], (string)end($route), (int)$fresh['revision']);
        $current = $started['character'];
        $iterations = 0;
        while (($current['route_progress']['status'] ?? '') === 'active' && $iterations < 20) {
            $result = $travel->advance($universe['id'], $character['id'], (int)$current['revision']);
            $current = $result['character'];
            $iterations++;
        }
        $equal('completed', $current['route_progress']['status'] ?? null, 'Completed route status missing from dashboard source data.');
        $equal((string)end($route), $current['current_system_id'], 'Dashboard location source did not reach the destination.');

        $globalTarget = (string)$systems[count($systems) - 1]['id'];
        $updatedUniverse = $universes->updateState($universe['id'], (int)$universe['state']['revision'], ['type' => 'system_explored', 'system_id' => $globalTarget]);
        $globalIds = array_column($updatedUniverse['state']['projections']['explored_systems'] ?? [], 'system_id');
        $assert(in_array($globalTarget, $globalIds, true), 'Global exploration projection was not updated.');
        return 'Character visit history, completed travel progress, and universe-wide exploration projection all update in persisted source data.';
    } finally { $cleanup($dir); }
});

$run('Travel next-jump control remains actionable and reports request failures', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    $assert(str_contains($html, "document.getElementById('advanceTravelButton').addEventListener('click', () => submitTravelAction('advance'))"), 'Travel next-jump click handler is missing.');
    $assert(str_contains($html, 'advanceButton.disabled = !canPlay;'), 'Active route must keep next-jump enabled only when character and universe are playable.');
    $assert(str_contains($html, "document.getElementById('advanceTravelButton').disabled = true;"), 'Next-jump control is not safely disabled when no character is selected.');
    $assert(str_contains($html, "status.textContent = 'Travel request failed: ' + String(error);"), 'Travel request errors are not visible in the Workbench.');
    $assert(str_contains($html, "button.disabled = !selectedCharacter;"), 'Next-jump control can remain disabled after a failed or stale request.');
    return 'Next-jump control has a click handler, actionable state, and visible error feedback.';
});


$run('Global menu exposes all major Workbench areas with accessible tab relationships', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach ([
        'role="tablist"', 'role="tab"', 'role="tabpanel"',
        'id="tab-overview"', 'id="panel-overview"',
        'id="tab-universe"', 'id="panel-universe"',
        'id="tab-characters"', 'id="panel-characters"',
        'id="tab-discoveries"', 'id="panel-discoveries"',
        'id="tab-operations"', 'id="panel-operations"',
        'aria-controls="panel-discoveries"', 'aria-labelledby="tab-discoveries"'
    ] as $needle) {
        $assert(str_contains($html, $needle), 'Global menu is missing accessibility or panel marker: ' . $needle);
    }
    return 'Five major work areas have explicit tab/panel relationships and accessible labels.';
});

$run('Global menu supports click, arrow-key, Home, and End navigation', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach (["tab.addEventListener('click'", "tab.addEventListener('keydown'", "event.key === 'ArrowRight'", "event.key === 'ArrowLeft'", "event.key === 'Home'", "event.key === 'End'", "panel.hidden = panel.dataset.panel !== name", "item.setAttribute('aria-selected'", "item.tabIndex = active ? 0 : -1"] as $needle) {
        $assert(str_contains($html, $needle), 'Global menu interaction is missing: ' . $needle);
    }
    return 'Tabs switch panels, update selected/focus state, and support standard keyboard navigation.';
});

$run('Overview dashboard is wired to current universe, character, location, and travel status', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach (['overviewUniverse','overviewCharacter','overviewRole','overviewSystem','overviewTravel'] as $needle) {
        $assert(str_contains($html, $needle), 'Overview dashboard is missing: ' . $needle);
    }
    $assert(str_contains($html, "set('overviewUniverse'") && str_contains($html, "set('overviewCharacter'") && str_contains($html, "set('overviewTravel'"), 'Overview dashboard fields are not updated by the character dashboard renderer.');
    $assert(str_contains($html, "activateTab('overview')"), 'Workbench does not initialize to a valid default tab.');
    return 'Overview tiles are updated alongside the existing character/travel dashboard and a default tab is initialized.';
});


$run('Ship fitting consumes materials, installs a module, and increments revision', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-fitting-success');
        $character = (new CharacterService($storage))->create($universe['id'], 'Ship Fitter');
        $record = $storage->read('characters', $character['id']); $record['inventory'] = ['resources' => ['ship_components' => 2, 'refined_alloy' => 3, 'tech_insights' => 1], 'ledger' => []]; $storage->write('characters', $character['id'], $record);
        $result = (new CharacterFittingService($storage))->install($universe['id'], $character['id'], 'propulsion_array', 0);
        $equal('propulsion_array', $result['character']['ship']['modules']['propulsion']['id'] ?? null, 'Propulsion module not installed.');
        $equal(1, $result['character']['inventory']['resources']['ship_components'], 'Ship component not consumed.');
        $equal(2, $result['character']['inventory']['resources']['refined_alloy'], 'Refined alloy not consumed.');
        $equal(1, $result['character']['revision'], 'Fitting should increment revision once.');
        $equal(2, count($result['character']['inventory']['ledger']), 'Fitting ledger entries missing.');
        $equal($result['character'], $storage->read('characters', $character['id']), 'Fitted character was not persisted.');
        return 'Module, material consumption, ledger entries, revision, and persisted character agree.';
    } finally { $cleanup($dir); }
});

$run('Ship fitting rejects occupied slots without changing inventory', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-fitting-slot');
        $character = (new CharacterService($storage))->create($universe['id'], 'Slot Tester');
        $record = $storage->read('characters', $character['id']); $record['inventory'] = ['resources' => ['ship_components' => 2, 'refined_alloy' => 3], 'ledger' => []]; $storage->write('characters', $character['id'], $record);
        $service = new CharacterFittingService($storage); $service->install($universe['id'], $character['id'], 'propulsion_array', 0);
        try { $service->install($universe['id'], $character['id'], 'propulsion_array', 1); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'slot is already occupied'), 'Unexpected occupied-slot error.'); $saved = $storage->read('characters', $character['id']); $equal(1, $saved['revision'], 'Rejected installation changed revision.'); $equal(1, $saved['inventory']['resources']['ship_components'], 'Rejected installation consumed components.'); $equal(2, count($saved['inventory']['ledger']), 'Rejected installation added ledger entries.'); return 'An occupied slot is rejected without further material consumption or revision changes.'; }
        throw new RuntimeException('Occupied module slot was accepted.');
    } finally { $cleanup($dir); }
});

$run('Ship fitting rejects insufficient materials and stale revisions', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-fitting-validation');
        $character = (new CharacterService($storage))->create($universe['id'], 'Fitting Validation');
        $record = $storage->read('characters', $character['id']); $record['inventory'] = ['resources' => ['ship_components' => 1], 'ledger' => []]; $storage->write('characters', $character['id'], $record); $service = new CharacterFittingService($storage);
        try { $service->install($universe['id'], $character['id'], 'propulsion_array', 0); } catch (RuntimeException $e) { $assert(str_contains(strtolower($e->getMessage()), 'insufficient refined alloy'), 'Unexpected insufficient-resource error.'); }
        try { $service->install($universe['id'], $character['id'], 'survey_scanner', 5); } catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'revision conflict'), 'Unexpected stale-revision error.'); }
        $saved = $storage->read('characters', $character['id']); $equal(0, $saved['revision'], 'Rejected fitting changed revision.'); $equal(['ship_components' => 1], $saved['inventory']['resources'], 'Rejected fitting changed resources.'); $equal([], $saved['inventory']['ledger'], 'Rejected fitting added ledger entries.');
        return 'Insufficient materials and stale revisions leave ship and inventory unchanged.';
    } finally { $cleanup($dir); }
});

$run('Workbench exposes ship fitting controls and persisted module slots', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__)); $assert(is_string($html), 'Workbench HTML could not be read.');
    foreach (['fitModule','fitModuleButton','fitModuleStatus','shipFittingPanel','api/character-fit.php','api/content-ship-modules.php','gameContent.ship_modules','character.ship?.modules'] as $needle) $assert(str_contains($html, $needle), 'Workbench is missing ship fitting marker: ' . $needle);
    return 'Workbench exposes module selection, installation action, status feedback, and all three fitting slots.';
});

$run('Permanent character deletion is rejected and preserves the complete character record', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-character-retention');
        $service = new CharacterService($storage); $character = $service->create($universe['id'], 'Retention Pilot');
        $record = $storage->read('characters', $character['id']); $record['inventory'] = ['resources' => ['raw_ore' => 5], 'ledger' => [['id' => 'test']]]; $storage->write('characters', $character['id'], $record);
        try { $service->deleteCharacter($universe['id'], $character['id'], 'Retention Pilot', 0); throw new RuntimeException('Permanent deletion unexpectedly succeeded.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Permanent character deletion is disabled by policy'), 'Retention policy was not explicit.'); }
        $equal($record, $storage->read('characters', $character['id']), 'Rejected deletion changed character data.');
        $equal($universe['id'], $storage->read('universes', $universe['id'])['id'] ?? null, 'Rejected deletion affected its universe.');
        return 'Permanent deletion is explicitly blocked; full character progress and universe remain unchanged.';
    } finally { $cleanup($dir); }
});

$run('Character deletion policy is consistent for missing, stale, and cross-universe requests', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universes = new UniverseService($storage); $universe = $universes->createOrLoad('core-ui-qa-character-retention-validation'); $otherUniverse = $universes->createOrLoad('core-ui-qa-character-retention-other');
        $service = new CharacterService($storage); $character = $service->create($universe['id'], 'Guarded Character');
        foreach ([[$universe['id'], 'Wrong Name', 0], [$universe['id'], 'Guarded Character', 1], [$otherUniverse['id'], 'Guarded Character', 0], [$universe['id'], 'Missing Character', 0, 'chr_missing123']] as $case) {
            [$uid, $name, $revision] = $case; $id = $case[3] ?? $character['id'];
            try { $service->deleteCharacter($uid, $id, $name, $revision); throw new RuntimeException('Permanent deletion unexpectedly succeeded.'); }
            catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Permanent character deletion is disabled by policy'), 'Unexpected deletion policy response: ' . $e->getMessage()); }
        }
        $equal($character['id'], $storage->read('characters', $character['id'])['id'] ?? null, 'Rejected deletion removed the character.');
        return 'All permanent deletion requests are consistently blocked without changing existing records.';
    } finally { $cleanup($dir); }
});

$run('Workbench exposes retention-safe character lifecycle instead of permanent deletion', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__)); $app = file_get_contents(dirname(__DIR__) . '/app/Application.php');
    $assert(is_string($html) && is_string($app), 'Workbench or application source could not be read.');
    foreach (['disableCharacterButton','enableCharacterButton','characterLifecycleStatus','Permanent character deletion is disabled','deleteManagedCharacterButton'] as $needle) $assert(str_contains($html, $needle), 'Workbench is missing retention/lifecycle marker: ' . $needle);
    $assert(str_contains($app, "'/api/characters/delete'"), 'Compatibility deletion route is missing; it must remain guarded by the service retention policy.');
    return 'Workbench provides reversible lifecycle controls and clearly communicates the permanent-retention policy.';
});


$run('Character lifecycle disable/enable is reversible and preserves all progress', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-lifecycle-disable');
        $characters = new CharacterService($storage); $character = $characters->create($universe['id'], 'Lifecycle Keeper');
        $record = $storage->read('characters', $character['id']); $record['inventory'] = ['resources' => ['raw_ore' => 7], 'ledger' => [['id' => 'keep-ledger']]]; $storage->write('characters', $character['id'], $record);
        $service = new CharacterLifecycleService($storage);
        $disabled = $service->apply($universe['id'], $character['id'], 'disable', 0);
        $equal(false, $disabled['character']['lifecycle']['enabled'], 'Disable did not persist.'); $equal(1, $disabled['character']['revision'], 'Disable did not advance revision.');
        $saved = $storage->read('characters', $character['id']); $equal(['raw_ore' => 7], $saved['inventory']['resources'], 'Disable changed inventory.'); $equal([['id' => 'keep-ledger']], $saved['inventory']['ledger'], 'Disable changed ledger.');
        $enabled = $service->apply($universe['id'], $character['id'], 'enable', 1); $equal(true, $enabled['character']['lifecycle']['enabled'], 'Enable did not restore character.');
        return 'Disable and enable are reversible, revision checked, and preserve inventory/ledger.';
    } finally { $cleanup($dir); }
});

$run('Locked or disabled characters cannot perform gameplay mutations', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-lifecycle-block'); $characters = new CharacterService($storage); $character = $characters->create($universe['id'], 'Frozen Explorer');
        $lifecycle = new CharacterLifecycleService($storage); $scan = new CharacterScanService($storage);
        $disabled = $lifecycle->apply($universe['id'], $character['id'], 'disable', 0)['character'];
        try { $scan->scanCurrentSystem($universe['id'], $character['id'], $disabled['revision']); throw new RuntimeException('Disabled character was allowed to scan.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'disabled'), 'Unexpected disabled action error: ' . $e->getMessage()); }
        $enabled = $lifecycle->apply($universe['id'], $character['id'], 'enable', $disabled['revision'])['character'];
        $locked = $lifecycle->apply($universe['id'], $character['id'], 'lock', $enabled['revision'])['character'];
        try { $scan->scanCurrentSystem($universe['id'], $character['id'], $locked['revision']); throw new RuntimeException('Locked character was allowed to scan.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'locked'), 'Unexpected locked action error: ' . $e->getMessage()); }
        $saved = $storage->read('characters', $character['id']); $equal([], $saved['scans']['systems'] ?? [], 'Rejected scans changed persisted discoveries.'); $equal($locked['revision'], $saved['revision'], 'Rejected scans changed revision.');
        return 'Disabled and locked characters are blocked server-side; rejected scans do not mutate state.';
    } finally { $cleanup($dir); }
});

$run('Lifecycle changes are idempotent and reject stale revisions or invalid actions', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-lifecycle-validation'); $character = (new CharacterService($storage))->create($universe['id'], 'Revision Guard'); $service = new CharacterLifecycleService($storage);
        $same = $service->apply($universe['id'], $character['id'], 'enable', 0); $equal('unchanged', $same['lifecycle_status'], 'Repeated enable should be idempotent.'); $equal(0, $same['character']['revision'], 'No-op enable changed revision.');
        foreach ([['disable', 3, 'revision conflict'], ['explode', 0, 'Action must']] as [$action, $revision, $expected]) {
            try { $service->apply($universe['id'], $character['id'], $action, $revision); throw new RuntimeException('Invalid lifecycle action accepted.'); }
            catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), $expected), 'Unexpected lifecycle validation error: ' . $e->getMessage()); }
        }
        $equal(0, $storage->read('characters', $character['id'])['revision'], 'Rejected lifecycle action mutated record.');
        return 'No-op actions preserve revision; stale revisions and invalid actions are rejected safely.';
    } finally { $cleanup($dir); }
});

$run('Workbench exposes reversible lifecycle controls and API wiring', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__)); $app = file_get_contents(dirname(__DIR__) . '/app/Application.php');
    $assert(is_string($html) && is_string($app), 'Workbench or application source could not be read.');
    foreach (['disableCharacterButton','enableCharacterButton','lockCharacterButton','unlockCharacterButton','characterLifecycleStatus','api/character-lifecycle.php','preserves all character data'] as $needle) $assert(str_contains($html, $needle), 'Workbench is missing lifecycle marker: ' . $needle);
    $assert(str_contains($app, "'/api/characters/lifecycle'"), 'Lifecycle API route is missing.');
    return 'Workbench includes disable/enable and lock/unlock controls with lifecycle API request wiring.';
});


$run('Universe lifecycle disable/enable and lock/unlock are reversible and preserve saved universe state', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $service = new UniverseService($storage); $universe = $service->createOrLoad('core-ui-qa-universe-lifecycle');
        $service->updateState($universe['id'], 0, ['type' => 'note_added', 'value' => 'keep me']);
        $lifecycle = new UniverseLifecycleService($storage);
        $disabled = $lifecycle->apply($universe['id'], 'disable', 0);
        $equal(false, $disabled['universe']['lifecycle']['enabled'], 'Disable was not persisted.');
        $equal(1, $disabled['universe']['lifecycle']['revision'], 'Lifecycle revision did not advance.');
        $enabled = $lifecycle->apply($universe['id'], 'enable', 1);
        $equal(true, $enabled['universe']['lifecycle']['enabled'], 'Enable did not restore universe.');
        $locked = $lifecycle->apply($universe['id'], 'lock', 2);
        $equal(true, $locked['universe']['lifecycle']['locked'], 'Lock was not persisted.');
        $unlocked = $lifecycle->apply($universe['id'], 'unlock', 3);
        $equal(false, $unlocked['universe']['lifecycle']['locked'], 'Unlock did not restore universe.');
        $saved = $storage->read('universes', $universe['id']);
        $equal(1, $saved['state']['revision'], 'Lifecycle actions changed universe event revision.');
        $equal('keep me', $saved['state']['projections']['notes'][0]['text'] ?? null, 'Lifecycle actions damaged universe state.');
        return 'Universe disable/enable and lock/unlock preserve generated baseline and event state.';
    } finally { $cleanup($dir); }
});

$run('Disabled or locked universes reject gameplay mutations server-side', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-universe-lifecycle-guard');
        $lifecycle = new UniverseLifecycleService($storage); $characters = new CharacterService($storage);
        $disabled = $lifecycle->apply($universe['id'], 'disable', 0)['universe'];
        try { $characters->create($universe['id'], 'Blocked Creation'); throw new RuntimeException('Character creation succeeded in disabled universe.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Universe is disabled'), 'Unexpected disabled-universe error: ' . $e->getMessage()); }
        $enabled = $lifecycle->apply($universe['id'], 'enable', $disabled['lifecycle']['revision'])['universe'];
        $character = $characters->create($universe['id'], 'Universe Guard');
        $locked = $lifecycle->apply($universe['id'], 'lock', $enabled['lifecycle']['revision'])['universe'];
        try { (new CharacterScanService($storage))->scanCurrentSystem($universe['id'], $character['id'], 0); throw new RuntimeException('Scan succeeded in locked universe.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Universe is locked'), 'Unexpected locked-universe error: ' . $e->getMessage()); }
        try { (new UniverseService($storage))->updateState($universe['id'], 0, ['type' => 'note_added', 'value' => 'blocked']); throw new RuntimeException('State update succeeded in locked universe.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Universe is locked'), 'Unexpected state-update error: ' . $e->getMessage()); }
        $equal([], $storage->read('characters', $character['id'])['scans']['systems'] ?? [], 'Rejected scan changed character state.');
        $equal(0, $storage->read('universes', $universe['id'])['state']['revision'], 'Rejected state update changed universe state.');
        return 'Character creation, scans, and universe-state writes are blocked when universe is disabled or locked.';
    } finally { $cleanup($dir); }
});

$run('Universe lifecycle actions are idempotent and reject stale revisions or invalid actions', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-ui-qa-universe-lifecycle-revision'); $service = new UniverseLifecycleService($storage);
        $same = $service->apply($universe['id'], 'enable', 0); $equal('unchanged', $same['lifecycle_status'], 'No-op enable should be idempotent.'); $equal(0, $same['universe']['lifecycle']['revision'], 'No-op changed lifecycle revision.');
        foreach ([['disable', 5, 'revision conflict'], ['remove', 0, 'Action must']] as [$action, $revision, $expected]) {
            try { $service->apply($universe['id'], $action, $revision); throw new RuntimeException('Invalid lifecycle action accepted.'); }
            catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), $expected), 'Unexpected lifecycle rejection: ' . $e->getMessage()); }
        }
        $savedLifecycle = $storage->read('universes', $universe['id'])['lifecycle'] ?? []; $equal(true, $savedLifecycle['enabled'] ?? null, 'Rejected action changed enabled state.'); $equal(false, $savedLifecycle['locked'] ?? null, 'Rejected action changed locked state.'); $equal(0, $savedLifecycle['revision'] ?? null, 'Rejected action changed lifecycle revision.');
        return 'No-op actions preserve revision; stale revisions and invalid actions are rejected without mutation.';
    } finally { $cleanup($dir); }
});

$run('Workbench exposes universe lifecycle controls and API request wiring', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__)); $app = file_get_contents(dirname(__DIR__) . '/app/Application.php');
    $assert(is_string($html) && is_string($app), 'Workbench or application source could not be read.');
    foreach (['disableUniverseButton','enableUniverseButton','lockUniverseButton','unlockUniverseButton','universeLifecycleStatus','api/universe-lifecycle.php','preserve saved data'] as $needle) $assert(str_contains($html, $needle), 'Workbench is missing universe lifecycle marker: ' . $needle);
    $assert(str_contains($app, "'/api/universe/lifecycle'"), 'Universe lifecycle API route is missing.');
    return 'Universe lifecycle controls, status display, and API wiring are present.';
});

$run('Data management inventory summarizes saved universes and characters without changing records', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-data-inventory-qa');
        $character = (new CharacterService($storage))->create($universe['id'], 'Inventory QA');
        $beforeUniverse = $storage->read('universes', $universe['id']); $beforeCharacter = $storage->read('characters', $character['id']);
        $inventory = (new DataManagementService($storage))->inventory();
        $equal(1, $inventory['summary']['universes'], 'Inventory universe count mismatch.');
        $equal(1, $inventory['summary']['characters'], 'Inventory character count mismatch.');
        $equal($universe['id'], $inventory['universes'][0]['id'], 'Inventory universe identity mismatch.');
        $equal($character['id'], $inventory['characters'][0]['id'], 'Inventory character identity mismatch.');
        $equal($beforeUniverse, $storage->read('universes', $universe['id']), 'Inventory changed the universe record.');
        $equal($beforeCharacter, $storage->read('characters', $character['id']), 'Inventory changed the character record.');
        return 'Inventory counts and identities matched; saved records remained unchanged.';
    } finally { $cleanup($dir); }
});

$run('Character deletion preview counts embedded gameplay data and remains read-only', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-character-preview-qa');
        $character = (new CharacterService($storage))->create($universe['id'], 'Preview QA');
        $character['inventory'] = ['resources' => ['raw_ore' => 3, 'salvage_parts' => 1], 'ledger' => []];
        $character['ship'] = ['modules' => ['scanner' => ['module_id' => 'survey_scanner']]];
        $character['scans'] = ['systems' => ['sys_1' => ['discoveries' => [['id' => 'dsc_1'], ['id' => 'dsc_2']]]]];
        $storage->write('characters', $character['id'], $character);
        $preview = (new DataManagementService($storage))->preview('character', $character['id']);
        $equal(true, $preview['executable'], 'Character preview should mark existing character deletion executable.');
        $equal(1, $preview['impact']['character_records'], 'Character record count mismatch.');
        $equal(2, $preview['impact']['inventory_stacks'], 'Inventory stack count mismatch.');
        $equal(1, $preview['impact']['scan_records'], 'Scan record count mismatch.');
        $equal(2, $preview['impact']['discoveries'], 'Discovery count mismatch.');
        $equal(1, $preview['impact']['fitted_modules'], 'Fitted module count mismatch.');
        $equal($character, $storage->read('characters', $character['id']), 'Preview mutated or deleted the character.');
        return 'Impact counts are correct and preview leaves the character unchanged.';
    } finally { $cleanup($dir); }
});

$run('Universe deletion preview is executable only with fresh revisions and reports dependent characters', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir); $universe = (new UniverseService($storage))->createOrLoad('core-universe-preview-qa');
        (new CharacterService($storage))->create($universe['id'], 'Dependent QA One');
        (new CharacterService($storage))->create($universe['id'], 'Dependent QA Two');
        $preview = (new DataManagementService($storage))->preview('universe', $universe['id']);
        $equal(true, $preview['executable'], 'Universe deletion should be available with guarded execution.');
        $equal(2, $preview['impact']['related_character_records'], 'Dependent character count mismatch.');
        $assert(str_contains($preview['warning'], 'checksum-verified backup first'), 'Backup-first safety warning missing.');
        $equal(2, count($preview['expected_character_ids']), 'Preview omitted expected dependent-character IDs.');
        $equal(2, count($storage->all('characters')), 'Universe preview changed character records.');
        $assert($storage->read('universes', $universe['id']) !== null, 'Universe preview deleted the universe.');
        return 'Universe impact, expected revisions, and dependent IDs are shown; preview remains read-only.';
    } finally { $cleanup($dir); }
});

$run('Data management rejects unknown records and invalid scopes', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-web-qa-' . bin2hex(random_bytes(8));
    try {
        $service = new DataManagementService(new JsonStorage($dir));
        foreach ([['character', 'missing'], ['planet', 'missing']] as [$scope, $id]) {
            try { $service->preview($scope, $id); throw new RuntimeException('Invalid preview request was accepted.'); }
            catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'does not exist') || str_contains($e->getMessage(), 'Scope must'), 'Unexpected preview validation message.'); }
        }
        return 'Missing records and unsupported scopes are rejected.';
    } finally { $cleanup($dir); }
});

$run('Workbench exposes data inventory, cleanup previews, and guarded character removal', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__)); $app = file_get_contents(dirname(__DIR__) . '/app/Application.php');
    $assert(is_string($html) && is_string($app), 'Workbench or application source could not be read.');
    foreach (['Data Management','refreshDataInventoryButton','previewCleanupButton','deleteManagedCharacterButton','api/data-management.php','api/data-management-preview.php','Permanent character deletion is disabled','DELETE UNIVERSE'] as $needle) $assert(str_contains($html, $needle) || str_contains($app, $needle), 'Data management wiring missing: ' . $needle);
    $assert(str_contains($app, "'/api/data-management'") && str_contains($app, "'/api/data-management/preview'"), 'Data management API routes missing.');
    return 'Inventory and read-only impact previews are present; permanent character removal is retired under the retention policy.';
});

$run('Universe backup snapshots include associated characters and checksum', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-backup-qa-' . bin2hex(random_bytes(6)); $dataDir = $dir . '/data'; $backupDir = $dir . '/backups';
    try {
        $storage = new JsonStorage($dataDir); $universe = ['id' => 'universe_backup_test', 'name' => 'Backup Test', 'seed' => 'backup-seed', 'baseline' => ['systems' => [['id' => 'sys1']]], 'state' => ['changes' => []]];
        $character = ['id' => 'character_backup_test', 'name' => 'Backup Pilot', 'universe_id' => $universe['id'], 'revision' => 3, 'inventory' => ['resources' => ['raw_ore' => 4]]];
        $storage->write('universes', $universe['id'], $universe); $storage->write('characters', $character['id'], $character);
        $service = new UniverseBackupService($storage, $backupDir); $backup = $service->create($universe['id']);
        $assert($backup['character_count'] === 1, 'Backup omitted associated character.'); $assert(strlen($backup['checksum_sha256']) === 64, 'Backup checksum missing.');
        $assert(count($service->list()) === 1, 'Backup not listed.'); return 'Universe and one associated character backed up with SHA-256 checksum.';
    } finally { $cleanup($dir); }
});
$run('Universe backup restore recovers deleted records and verifies them', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-restore-qa-' . bin2hex(random_bytes(6));
    try {
        $storage = new JsonStorage($dir . '/data'); $universe = ['id' => 'universe_restore_test', 'name' => 'Restore Test', 'seed' => 'restore-seed', 'baseline' => ['systems' => []], 'state' => ['changes' => []]];
        $character = ['id' => 'character_restore_test', 'name' => 'Restore Pilot', 'universe_id' => $universe['id'], 'revision' => 2];
        $storage->write('universes', $universe['id'], $universe); $storage->write('characters', $character['id'], $character);
        $service = new UniverseBackupService($storage, $dir . '/backups'); $backup = $service->create($universe['id']);
        $storage->delete('characters', $character['id'], static fn(array $r) => null); $storage->delete('universes', $universe['id'], static fn(array $r) => null);
        $result = $service->restore($backup['backup_id']); $assert($result['verified'] === true, 'Restore was not verified.');
        $assert($storage->read('universes', $universe['id']) === $universe, 'Universe was not restored exactly.'); $assert($storage->read('characters', $character['id']) === $character, 'Character was not restored exactly.');
        return 'Deleted universe and character records restored exactly from snapshot.';
    } finally { $cleanup($dir); }
});
$run('Universe backup restore refuses conflicting live records', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-restore-conflict-qa-' . bin2hex(random_bytes(6));
    try {
        $storage = new JsonStorage($dir . '/data'); $universe = ['id' => 'universe_conflict_test', 'name' => 'Original', 'seed' => 'conflict-seed', 'baseline' => ['systems' => []], 'state' => ['changes' => []]];
        $storage->write('universes', $universe['id'], $universe); $service = new UniverseBackupService($storage, $dir . '/backups'); $backup = $service->create($universe['id']);
        $storage->write('universes', $universe['id'], ['id' => $universe['id'], 'name' => 'Different live record']);
        try { $service->restore($backup['backup_id']); throw new RuntimeException('Conflicting record was overwritten.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'conflict'), 'Unexpected conflict rejection.'); }
        $assert(($storage->read('universes', $universe['id'])['name'] ?? '') === 'Different live record', 'Conflict changed live record.');
        return 'Restore refused conflicting record without overwriting it.';
    } finally { $cleanup($dir); }
});
$run('Backup UI and API wiring are present', static function () use ($assert): string {
    $root = dirname(__DIR__); $html = coreWorkbenchSource($root); $app = file_get_contents($root . '/app/Application.php'); $module = file_get_contents($root . '/app/Modules/Universe/UniverseModule.php');
    foreach (['createUniverseBackupButton', 'refreshBackupsButton', 'restoreUniverseBackupButton', 'backupRestoreConfirmation', 'storage/backups/'] as $needle) $assert(str_contains($html, $needle), 'Backup UI marker missing: ' . $needle);
    foreach (['/api/data-management/backups', '/api/data-management/backups/restore'] as $needle) $assert(str_contains($app, $needle), 'Backup API route marker missing: ' . $needle);
    $assert(str_contains($module, 'UniverseBackupService'), 'Backup service is not registered by the universe module.');
    return 'Backup, list, and guarded restore controls are wired to server routes.';
});

$run('Universe deletion is blocked while permanent character records are associated', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-delete-universe-qa-' . bin2hex(random_bytes(6));
    try {
        $storage = new JsonStorage($dir . '/data');
        $universe = ['id' => 'universe_delete_test', 'name' => 'Delete Test', 'seed' => 'delete-seed', 'baseline' => ['systems' => [['id' => 'sys1']]], 'state' => ['revision' => 2, 'changes' => [['type' => 'test']]], 'lifecycle' => ['enabled' => true, 'locked' => false, 'revision' => 1]];
        $character = ['id' => 'character_delete_test', 'name' => 'Retained Pilot', 'universe_id' => $universe['id'], 'revision' => 4, 'inventory' => ['resources' => ['raw_ore' => 3]]];
        $storage->write('universes', $universe['id'], $universe); $storage->write('characters', $character['id'], $character);
        $backups = new UniverseBackupService($storage, $dir . '/backups'); $service = new UniverseDeletionService($storage, $backups);
        try { $service->delete($universe['id'], 'DELETE UNIVERSE ' . $universe['id'], 2, 1, [$character['id']]); throw new RuntimeException('Universe with a dependent character was deleted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'associated character records'), 'Unexpected retention rejection: ' . $e->getMessage()); }
        $equal($universe, $storage->read('universes', $universe['id']), 'Blocked deletion changed universe.');
        $equal($character, $storage->read('characters', $character['id']), 'Blocked deletion changed character.');
        $assert($backups->list() === [], 'Blocked deletion should not create a backup.');
        return 'Universe removal is blocked before backup when associated permanent characters exist; all records remain unchanged.';
    } finally { $cleanup($dir); }
});
$run('Universe deletion rejects incorrect confirmation before creating a backup', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-delete-confirm-qa-' . bin2hex(random_bytes(6));
    try {
        $storage = new JsonStorage($dir . '/data'); $universe = ['id' => 'universe_confirm_test', 'name' => 'Confirm', 'state' => ['revision' => 0, 'changes' => []], 'lifecycle' => ['revision' => 0]];
        $storage->write('universes', $universe['id'], $universe); $backups = new UniverseBackupService($storage, $dir . '/backups'); $service = new UniverseDeletionService($storage, $backups);
        try { $service->delete($universe['id'], 'DELETE', 0, 0, []); throw new RuntimeException('Incorrect confirmation was accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Confirmation must exactly match'), 'Unexpected confirmation failure.'); }
        $assert($storage->read('universes', $universe['id']) === $universe, 'Universe changed after invalid confirmation.');
        $assert($backups->list() === [], 'Backup should not be created before confirmation validation.');
        return 'Incorrect confirmation rejected before backup or mutation.';
    } finally { $cleanup($dir); }
});
$run('Universe deletion validates stale revisions and refuses dependent-character removal', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-delete-stale-qa-' . bin2hex(random_bytes(6));
    try {
        $storage = new JsonStorage($dir . '/data'); $universe = ['id' => 'universe_stale_delete_test', 'name' => 'Stale', 'state' => ['revision' => 2, 'changes' => []], 'lifecycle' => ['revision' => 3]];
        $storage->write('universes', $universe['id'], $universe);
        $backups = new UniverseBackupService($storage, $dir . '/backups'); $service = new UniverseDeletionService($storage, $backups);
        try { $service->delete($universe['id'], 'DELETE UNIVERSE ' . $universe['id'], 1, 3, []); throw new RuntimeException('Stale revision was accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'stale'), 'Unexpected stale revision rejection: ' . $e->getMessage()); }
        $character = ['id' => 'character_stale_delete_test', 'name' => 'Retained Pilot', 'universe_id' => $universe['id'], 'revision' => 1]; $storage->write('characters', $character['id'], $character);
        try { $service->delete($universe['id'], 'DELETE UNIVERSE ' . $universe['id'], 2, 3, [$character['id']]); throw new RuntimeException('Universe with dependent character was accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'associated character records'), 'Unexpected dependent-record rejection: ' . $e->getMessage()); }
        $assert($storage->read('universes', $universe['id']) === $universe, 'Rejected deletion modified universe.');
        $assert($storage->read('characters', $character['id']) === $character, 'Rejected deletion modified character.');
        $assert($backups->list() === [], 'Rejected deletion should not create a backup.');
        return 'Stale revisions are rejected when no dependents exist; dependent permanent characters block universe deletion without mutation.';
    } finally { $cleanup($dir); }
});
$run('Atomic universe deletion stages the universe and dependents as one verified set', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-atomic-delete-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir . '/data');
        $universe = ['id' => 'universe_atomic_qa', 'state' => ['revision' => 0, 'changes' => []]];
        $characterA = ['id' => 'character_atomic_a', 'universe_id' => $universe['id'], 'revision' => 0];
        $characterB = ['id' => 'character_atomic_b', 'universe_id' => $universe['id'], 'revision' => 0];
        $storage->write('universes', $universe['id'], $universe);
        $storage->write('characters', $characterA['id'], $characterA);
        $storage->write('characters', $characterB['id'], $characterB);
        $transaction = $storage->deleteBatchAtomically([
            ['collection' => 'universes', 'id' => $universe['id'], 'expected' => $universe],
            ['collection' => 'characters', 'id' => $characterA['id'], 'expected' => $characterA],
            ['collection' => 'characters', 'id' => $characterB['id'], 'expected' => $characterB],
        ], 'ud_' . bin2hex(random_bytes(12)), static function (): void {});
        $equal(3, $transaction['deleted_count'], 'Atomic transaction record count mismatch.');
        $equal(true, $transaction['verified'], 'Atomic transaction did not verify.');
        foreach ([['universes', $universe['id']], ['characters', $characterA['id']], ['characters', $characterB['id']]] as [$collection, $id]) {
            $equal(null, $storage->read($collection, $id), 'Record remained live after atomic deletion: ' . $id);
            $assert(is_file($dir . '/data/' . $collection . '/' . $id . '.json.lock'), 'Record lock tombstone was removed: ' . $id);
        }
        $assert(!is_dir($dir . '/data/.transactions/' . 'delete_' . $transaction['transaction_id']), 'Committed transaction staging directory was not cleaned.');
        return 'Universe and both dependents were removed as one verified staged transaction; lock files were retained.';
    } finally { $cleanup($dir); }
});

$run('Atomic universe deletion aborts before moving records when the final guard rejects', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-atomic-delete-guard-qa-' . bin2hex(random_bytes(8));
    try {
        $storage = new JsonStorage($dir . '/data');
        $universe = ['id' => 'universe_atomic_guard_qa', 'state' => ['revision' => 0, 'changes' => []]];
        $character = ['id' => 'character_atomic_guard_qa', 'universe_id' => $universe['id'], 'revision' => 0];
        $storage->write('universes', $universe['id'], $universe); $storage->write('characters', $character['id'], $character);
        $transactionId = 'ud_' . bin2hex(random_bytes(12));
        try {
            $storage->deleteBatchAtomically([
                ['collection' => 'universes', 'id' => $universe['id'], 'expected' => $universe],
                ['collection' => 'characters', 'id' => $character['id'], 'expected' => $character],
            ], $transactionId, static function (): void { throw new RuntimeException('Injected final-guard rejection.'); });
            throw new RuntimeException('Rejected final guard was ignored.');
        } catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'before any live record was moved'), 'Unexpected guard failure response: ' . $e->getMessage()); }
        $equal($universe, $storage->read('universes', $universe['id']), 'Universe changed after pre-move rejection.');
        $equal($character, $storage->read('characters', $character['id']), 'Character changed after pre-move rejection.');
        $assert(!is_dir($dir . '/data/.transactions/delete_' . $transactionId), 'Empty failed transaction directory was retained.');
        return 'Final guard rejection left both live records byte-equivalent at the decoded-record level and removed empty staging.';
    } finally { $cleanup($dir); }
});

$run('Character creation and universe deletion share the universe lock', static function () use ($assert): string {
    $characters = file_get_contents(dirname(__DIR__) . '/app/Modules/Characters/CharacterService.php');
    $storage = file_get_contents(dirname(__DIR__) . '/app/Storage/JsonStorage.php');
    $deletion = file_get_contents(dirname(__DIR__) . '/app/Modules/UniverseDeletionService.php');
    $assert(str_contains($characters, "withRecordLockOperation('universes', \$universeId"), 'Character creation does not hold the universe lock.');
    $assert(str_contains($storage, 'deleteBatchAtomically'), 'Atomic batch deletion primitive is missing.');
    $assert(str_contains($storage, 'Caller order is intentional: universe lock first'), 'Atomic deletion lock ordering is undocumented or changed.');
    $assert(str_contains($deletion, 'deleteBatchAtomically($records, $transactionId'), 'Universe deletion is not using atomic batch staging.');
    $assert(str_contains($deletion, 'currentCharacters !== $characterSnapshots'), 'Final dependent-character snapshot guard is missing.');
    $storageProtection = file_get_contents(dirname(__DIR__) . '/storage/.htaccess');
    $assert(is_string($storageProtection) && str_contains($storageProtection, 'Require all denied') && str_contains($storageProtection, 'Deny from all'), 'Storage files and recovery transactions are not protected from direct HTTP access.');
    return 'Character creation serializes on the universe lock; deletion acquires universe then sorted character locks and rechecks the dependent set before staging. Storage records, backups, logs, and recovery transactions are denied direct HTTP access.';
});

$run('Universe deletion API and confirmation UI are wired', static function () use ($assert): string {
    $root = dirname(__DIR__); $html = coreWorkbenchSource($root); $app = file_get_contents($root . '/app/Application.php'); $module = file_get_contents($root . '/app/Modules/Universe/UniverseModule.php'); $endpoint = file_get_contents($root . '/api/data-management-universe-delete.php');
    foreach (['deleteManagedUniverseButton', 'cleanupUniverseConfirmation', 'DELETE UNIVERSE ', 'pre-deletion backup'] as $needle) $assert(str_contains($html, $needle), 'Universe deletion UI marker missing: ' . $needle);
    foreach (["'/api/data-management/universe-delete'", 'developmentRequestAllowed'] as $needle) $assert(str_contains($app, $needle), 'Universe deletion API route marker missing: ' . $needle);
    $assert(str_contains($module, 'UniverseDeletionService'), 'Universe deletion service is not registered by the universe module.');
    $assert(str_contains($endpoint, '/api/data-management/universe-delete'), 'Universe deletion endpoint wrapper missing.');
    return 'Universe deletion has explicit UI confirmation, guarded development-only API route, and service wiring.';
});

$run('Universe deletion selection is searchable and displays the exact ID phrase', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    foreach (['managedUniverseSearch', 'managedUniverseTarget', 'previewUniverseDeletionButton', 'universeConfirmationPhrase', 'cleanupRecordSearch', 'cleanupRecordCount'] as $needle) $assert(str_contains($html, $needle), 'Universe deletion usability control missing: ' . $needle);
    $assert(!str_contains($html, 'copyUniverseConfirmationPhraseButton') && !str_contains($html, 'Copy phrase'), 'Unreliable copy-phrase button should be removed; phrase must remain manually selectable.');
    $assert(str_contains($html, "includes(query)"), 'Search must match universe names and IDs.');
    $assert(str_contains($html, "'DELETE UNIVERSE ' + data.preview.id"), 'Exact confirmation phrase is not generated from selected ID.');
    $assert(str_contains($html, 'readonly value="Generate a fresh preview to show the phrase"'), 'Exact phrase field must remain visible and selectable for manual copy.');
    return 'Universe selector/search and visible, manually selectable exact confirmation phrase are present; unreliable copy button is absent.';
});
$run('Incorrect universe deletion confirmation gives visible live feedback', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    foreach (['aria-live="assertive"', 'Confirmation does not match. Required phrase:', 'No data has been deleted.', 'updateUniverseDeleteConfirmationState', 'setVisibleStatus(status, \'Deletion failed:'] as $needle) $assert(str_contains($html, $needle), 'Visible deletion feedback marker missing: ' . $needle);
    $assert(str_contains($html, 'button.disabled = !matches'), 'Delete action must be disabled until confirmation exactly matches.');
    return 'Mismatched confirmation and API failures are shown in a high-contrast live status; unsafe action remains disabled.';
});
$run('Universe deletion UI reports progress, failure, and requires a fresh preview after errors', static function () use ($assert): string {
    $html = coreWorkbenchSource(dirname(__DIR__));
    foreach (['Universe deletion started', 'Step 1 of 3: creating and verifying the pre-deletion backup', 'Deletion failed:', 'Generate a fresh preview before retrying.', 'storage/logs/universe-deletion.log', 'storage/logs/backups.log', 'Universe deletion failed'] as $needle) $assert(str_contains($html, $needle), 'Deletion progress/error handling missing: ' . $needle);
    return 'Destructive operation has start/progress messages, actionable failure details, activity logging, and stale-preview invalidation.';
});

$run('Focused logging and deletion permission preflight are implemented', static function () use ($assert): string {
    $logger = file_get_contents(dirname(__DIR__) . '/app/Core/Logger.php');
    $storage = file_get_contents(dirname(__DIR__) . '/app/Storage/JsonStorage.php');
    $deletion = file_get_contents(dirname(__DIR__) . '/app/Modules/UniverseDeletionService.php');
    foreach (['api', 'storage', 'universe-deletion', 'backups', 'security', 'php-errors', 'errors'] as $channel) $assert(str_contains($logger, "'" . $channel . "'"), 'Missing focused log channel: ' . $channel);
    foreach (['lock_path', 'directory_writable', 'last_php_error'] as $detail) $assert(str_contains($storage, "'" . $detail . "'"), 'Storage lock diagnostics missing: ' . $detail);
    $assert(str_contains($storage, 'assertRecordLockUsable'), 'Existing lock-file usability preflight is missing.');
    $assert(str_contains($storage, "fopen(\$lockPath, 'r')"), 'Read-only lock-file fallback is missing.');
    $assert(str_contains($storage, 'Never unlink/recreate a lock file'), 'Lock handling must preserve lock-file identity.');
    $assert(str_contains($deletion, "assertCollectionWritable('characters')") && str_contains($deletion, "assertCollectionWritable('universes')"), 'Deletion does not preflight target collections.');
    $assert(str_contains($deletion, "storage/logs/universe-deletion.log and storage/logs/backups.log"), 'Failure response does not identify focused deletion and backup logs.');
    $assert(str_contains($logger, "array_key_exists('rollback_failure', \$context)"), 'Rollback failure is not routed to backups.log.');
    return 'Central and focused logs are retained; deletion verifies that each existing lock can be opened and exclusively locked before creating a backup. Readable read-only lock files are supported without unlinking or changing their permissions.';
});

$run('Game item, recipe, discovery, and ship-module definitions are external JSON catalogs', static function () use ($assert): string {
    $docs = ContentCatalog::allDocuments();
    foreach (['items','recipes','discoveries','ship_modules'] as $name) $assert(is_array($docs[$name]['entries'] ?? null) && count($docs[$name]['entries']) > 0, 'Missing JSON content catalog: ' . $name);
    $assert(isset($docs['item_categories']['entries']['resource'], $docs['item_categories']['entries']['material'], $docs['item_categories']['entries']['component']), 'Item category JSON definitions are missing.');
    $assert(is_array($docs['discoveries']['scan_rules'] ?? null), 'Scan generation rules are not externally configured in discoveries.json.');
    return 'All current gameplay definitions load from config/content JSON files.';
});

$run('Content API wrappers expose the editable JSON catalogs', static function () use ($assert): string {
    $root = dirname(__DIR__);
    foreach (['content.php','content-items.php','content-recipes.php','content-discoveries.php','content-ship-modules.php','content-item-categories.php'] as $file) $assert(is_file($root . '/api/' . $file), 'Missing content API wrapper: ' . $file);
    foreach (['items.json','recipes.json','discoveries.json','ship-modules.json','item-categories.json'] as $file) $assert(is_file($root . '/config/content/' . $file), 'Missing content JSON: ' . $file);
    return 'Aggregate and individual read-only content API wrappers are present.';
});

$run('Complete character-record API is available for saved player state', static function () use ($assert): string {
    $app = file_get_contents(dirname(__DIR__) . '/app/Application.php');
    $wrapper = dirname(__DIR__) . '/api/character-record.php';
    $assert(is_string($app) && str_contains($app, "'/api/characters/record'"), 'Single-character read route is missing.');
    $assert(is_file($wrapper), 'Single-character API wrapper is missing.');
    $assert(str_contains($app, "getById"), 'Character API does not return the complete persisted record.');
    return 'A character can be read as one JSON API record including inventory, scans, exploration, ledger, and ship state.';
});


$run('Content manager validates references across all JSON catalogs', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-content-manager-qa-' . bin2hex(random_bytes(8));
    try {
        $content = $dir . '/content'; mkdir($content, 0770, true);
        foreach (['items.json', 'recipes.json', 'discoveries.json', 'ship-modules.json'] as $file) copy(CORE_ROOT . '/config/content/' . $file, $content . '/' . $file);
        $manager = new ContentManagementService($content, $dir . '/backups');
        $doc = json_decode((string)file_get_contents($content . '/recipes.json'), true, 512, JSON_THROW_ON_ERROR);
        $doc['entries']['refine_ore']['inputs']['unknown_item'] = 1;
        try { $manager->validate('recipes', $doc); throw new RuntimeException('Unknown recipe input was accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Invalid recipe input'), 'Unexpected validation error: ' . $e->getMessage()); }
        return 'Invalid cross-catalog item reference rejected before save.';
    } finally { $cleanup($dir); }
});
$run('Content manager saves atomically and keeps verified previous version', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-content-save-qa-' . bin2hex(random_bytes(8));
    try {
        $content = $dir . '/content'; mkdir($content, 0770, true);
        foreach (['items.json', 'recipes.json', 'discoveries.json', 'ship-modules.json'] as $file) copy(CORE_ROOT . '/config/content/' . $file, $content . '/' . $file);
        $manager = new ContentManagementService($content, $dir . '/backups');
        $doc = json_decode((string)file_get_contents($content . '/recipes.json'), true, 512, JSON_THROW_ON_ERROR);
        $doc['entries']['refine_ore']['description'] = 'QA changed description';
        $saved = $manager->save('recipes', 1, $doc);
        $equal(2, $saved['revision'], 'Content revision did not increment.');
        $backup = $dir . '/backups/content/' . $saved['backup_file'];
        $assert(is_file($backup), 'Previous content backup is missing.');
        $old = json_decode((string)file_get_contents($backup), true, 512, JSON_THROW_ON_ERROR);
        $assert($old['entries']['refine_ore']['description'] !== 'QA changed description', 'Backup was not the previous catalog.');
        return 'Catalog revision incremented and prior JSON was backed up and verified.';
    } finally { $cleanup($dir); }
});
$run('Content manager rejects stale revision without overwriting newer edit', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-content-stale-qa-' . bin2hex(random_bytes(8));
    try {
        $content = $dir . '/content'; mkdir($content, 0770, true);
        foreach (['items.json', 'recipes.json', 'discoveries.json', 'ship-modules.json'] as $file) copy(CORE_ROOT . '/config/content/' . $file, $content . '/' . $file);
        $manager = new ContentManagementService($content, $dir . '/backups');
        $doc = json_decode((string)file_get_contents($content . '/recipes.json'), true, 512, JSON_THROW_ON_ERROR);
        $doc['entries']['refine_ore']['description'] = 'New edit'; $manager->save('recipes', 1, $doc);
        $doc['entries']['refine_ore']['description'] = 'Stale edit';
        try { $manager->save('recipes', 1, $doc); throw new RuntimeException('Stale content revision was accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'revision conflict'), 'Unexpected stale revision error: ' . $e->getMessage()); }
        $saved = json_decode((string)file_get_contents($content . '/recipes.json'), true, 512, JSON_THROW_ON_ERROR);
        $assert($saved['entries']['refine_ore']['description'] === 'New edit', 'Stale edit overwrote current catalog.');
        return 'Stale revision rejected and current catalog preserved.';
    } finally { $cleanup($dir); }
});


$run('Item categories are a JSON-defined dropdown and arbitrary categories are rejected', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $html = (string)coreWorkbenchSource($root);
    $application = (string)file_get_contents($root . '/app/Application.php');
    $categoryJson = json_decode((string)file_get_contents($root . '/config/content/item-categories.json'), true, 512, JSON_THROW_ON_ERROR);
    $assert(isset($categoryJson['entries']['resource']['label'], $categoryJson['entries']['material']['label'], $categoryJson['entries']['component']['label']), 'Expected item category labels are missing.');
    $assert(str_contains($html, 'function itemCategoryOptions(selected'), 'Category dropdown helper is missing.');
    $assert(str_contains($html, 'data-field="category" required'), 'Category select is not required.');
    $assert(str_contains($application, '/api/content/item-categories'), 'Dedicated category API route is missing.');
    $items = ContentCatalog::document('items')['entries'];
    foreach ($items as $id => $item) $assert(isset($categoryJson['entries'][$item['category']]), 'Item ' . $id . ' references an unknown category.');
    return 'Item category labels load from JSON; item forms use a required dropdown; every configured item category is allow-listed.';
});

$run('Required text characteristic validation rejects blank and whitespace-only values', static function () use ($assert): string {
    $schema = ContentCatalog::itemCharacteristicsDocument();
    $schema['categories']['resource']['fields']['qa_required_text'] = ['label'=>'QA required text','type'=>'text','required'=>true,'min_length'=>1,'default'=>'valid'];
    foreach (['', '   '] as $bad) {
        $docs = ['items'=>ContentCatalog::document('items'),'recipes'=>ContentCatalog::document('recipes'),'discoveries'=>ContentCatalog::document('discoveries'),'ship_modules'=>ContentCatalog::document('ship_modules')];
        $docs['items']['entries']['raw_ore']['characteristics']['qa_required_text'] = $bad;
        try { ContentCatalog::validateDocuments($docs, $schema); throw new RuntimeException('Blank required text was accepted.'); }
        catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Invalid value for item characteristic'), 'Unexpected validation error: '.$e->getMessage()); }
    }
    return 'Required text rejects empty and whitespace-only values during server-side catalog validation using an isolated in-memory schema.';
});
$run('Structured characteristic editor applies defaults and enforces required and length constraints', static function () use ($assert): string {
    $html = (string)coreWorkbenchSource(dirname(__DIR__));
    foreach (['field.default','field.min_length','field.max_length','control.required','Characteristic ${key} is required.'] as $needle) $assert(str_contains($html, $needle), 'Missing editor behavior: '.$needle);
    return 'Default values, required fields, and text-length constraints are represented in the structured editor.';
});

$run('Item characteristic values persist through revision-checked save and reload', static function () use ($assert): string {
    $root = dirname(__DIR__); $dir = sys_get_temp_dir() . '/core-web-item-characteristics-roundtrip-' . bin2hex(random_bytes(8));
    try {
        $content = $dir . '/content'; if (!mkdir($content, 0770, true) && !is_dir($content)) throw new RuntimeException('Could not create temporary content directory.');
        foreach (['items.json', 'recipes.json', 'discoveries.json', 'ship-modules.json'] as $file) if (!copy($root . '/config/content/' . $file, $content . '/' . $file)) throw new RuntimeException('Could not copy catalog: ' . $file);
        $manager = new ContentManagementService($content, $dir . '/backups');
        $document = json_decode((string)file_get_contents($content . '/items.json'), true, 512, JSON_THROW_ON_ERROR);
        $document['entries']['raw_ore']['characteristics']['rarity'] = 'exceptional';
        $saved = $manager->save('items', 1, $document);
        $assert($saved['revision'] === 2, 'Item catalog revision did not increment.');
        $reloaded = json_decode((string)file_get_contents($content . '/items.json'), true, 512, JSON_THROW_ON_ERROR);
        $assert(($reloaded['entries']['raw_ore']['characteristics']['rarity'] ?? null) === 'exceptional', 'Characteristic value did not survive save/reload.');
        $backup = json_decode((string)file_get_contents($dir . '/backups/content/' . $saved['backup_file']), true, 512, JSON_THROW_ON_ERROR);
        $assert(($backup['entries']['raw_ore']['characteristics']['rarity'] ?? null) === 'common', 'Verified backup did not preserve the prior characteristic value.');
        return 'A typed characteristic survived an item-catalog save/reload, revision increment, and previous-version backup.';
    } finally {
        if (is_dir($dir)) { $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST); foreach ($it as $item) $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname()); @rmdir($dir); }
    }
});

$run('Item characteristic schema is JSON-defined and available through the content API', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $schema = ContentCatalog::itemCharacteristicsDocument();
    $assert(isset($schema['categories']['resource']['fields']['rarity']['options']['rare']), 'Rarity schema is missing.');
    $assert(is_file($root . '/api/content-item-characteristics.php'), 'Characteristic schema API wrapper is missing.');
    $all = ContentCatalog::allDocuments();
    $assert(isset($all['item_characteristics']['entries']['component']), 'Aggregate API lacks characteristic schema.');
    return 'Category-specific characteristic definitions are loaded from JSON and exposed through the aggregate and dedicated API.';
});
$run('Item characteristic validation rejects unknown enum values and fields', static function () use ($assert): string {
    $docs = ['items'=>ContentCatalog::document('items'), 'recipes'=>ContentCatalog::document('recipes'), 'discoveries'=>ContentCatalog::document('discoveries'), 'ship_modules'=>ContentCatalog::document('ship_modules')];
    $docs['items']['entries']['raw_ore']['characteristics']['rarity'] = 'not_a_rarity';
    try { ContentCatalog::validateDocuments($docs); throw new RuntimeException('Invalid enum characteristic was accepted.'); }
    catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Invalid value for item characteristic'), 'Unexpected enum error: ' . $e->getMessage()); }
    $docs['items'] = ContentCatalog::document('items');
    $docs['items']['entries']['raw_ore']['characteristics']['not_defined'] = 'value';
    try { ContentCatalog::validateDocuments($docs); throw new RuntimeException('Unknown characteristic was accepted.'); }
    catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'Unknown item characteristic'), 'Unexpected unknown field error: ' . $e->getMessage()); }
    return 'Invalid characteristic choices and undefined fields are rejected before save.';
});
$run('Content Studio renders typed item characteristic fields from JSON schema', static function () use ($assert): string {
    $root = dirname(__DIR__); $html = (string)coreWorkbenchSource($root);
    $assert(str_contains($html, 'function renderCharacteristicFields(categoryId'), 'Dynamic characteristic editor is missing.');
    $assert(str_contains($html, 'data-characteristic-type="enum"'), 'Enum dropdown rendering is missing.');
    $assert(str_contains($html, 'entry.characteristics=readCharacteristicValues()'), 'Item form does not save characteristic values.');
    return 'Item editor renders schema-driven fields and carries their typed values into the draft.';
});

$run('Characteristic schema manager exposes form controls and mutation endpoints', static function () use ($assert): string {
    $root=dirname(__DIR__); $html=(string)coreWorkbenchSource($root); $app=(string)file_get_contents($root.'/app/Application.php');
    foreach (['schemaCategorySelect','schemaFieldSelect','schemaFieldType','schemaFieldRequired','schemaFieldDefault','schemaFieldMin','schemaFieldMax','schemaFieldOptions','schemaApplyFieldButton','schemaValidateButton','schemaSaveButton'] as $id) $assert(str_contains($html,'id="'.$id.'"'),'Characteristic form control is missing: '.$id);
    $assert(str_contains($app,"'/api/content/item-characteristics/validate'"),'Schema validation endpoint is missing.');
    $assert(str_contains($app,"'/api/content/item-characteristics/save'"),'Schema save endpoint is missing.');
    $assert(is_file($root.'/app/Modules/ItemCharacteristicsManagementService.php'),'Schema manager service is missing.');
    return 'Form controls support category-specific field definitions and dedicated validation/save endpoints.';
});
$run('Characteristic schema manager validates existing item values before save', static function () use ($assert): string {
    $root=dirname(__DIR__); $schema=ContentCatalog::itemCharacteristicsDocument();
    $manager=new Core\Modules\ItemCharacteristicsManagementService($root.'/config/content',$root.'/storage/backups');
    $result=$manager->validate($schema);
    $assert($result['valid']===true,'Current schema should be valid.');
    $assert($result['existing_items_checked']===count(ContentCatalog::document('items')['entries']),'Not every existing item was checked.');
    $schema['categories']['resource']['fields']['rarity']['options']=['common'=>'Common'];
    try {$manager->validate($schema);throw new RuntimeException('Schema invalidating existing enum values was accepted.');}
    catch(RuntimeException $e){$assert(str_contains($e->getMessage(),'invalidate existing items'),'Unexpected schema compatibility error: '.$e->getMessage());}
    return 'Existing item values are checked against proposed definitions and incompatible schema changes are rejected.';
});
$run('Characteristic schema changes use revision checks, atomic saves, and verified backups', static function () use ($assert): string {
    $root=dirname(__DIR__); $service=(string)file_get_contents($root.'/app/Modules/ItemCharacteristicsManagementService.php');
    foreach (['Content revision conflict','LOCK_EX','rename($temp,$path)','hash_equals(hash(\'sha256\',$old)','Logger::info'] as $needle) $assert(str_contains($service,$needle),'Missing schema safety control: '.$needle);
    return 'Schema service uses revision checks, file locking, verified backups, atomic replacement, and logs.';
});

$run('Workbench exposes structured content management and revision-checked APIs', static function () use ($assert): string {
    $root = dirname(__DIR__); $html = (string)coreWorkbenchSource($root);
    foreach (['tab-content', 'panel-content', 'contentCatalogSelect', 'contentJsonEditor', 'contentEntrySelect', 'contentEntryForm', 'contentAddEntryButton', 'contentApplyEntryButton', 'contentUseJsonButton', 'contentLoadButton', 'contentValidateButton', 'contentSaveButton', 'api/content-validate.php', 'api/content-save.php'] as $needle) {
        if (str_starts_with($needle, 'api/')) $assert(is_file($root . '/' . $needle), 'Missing content management API wrapper: ' . $needle);
        else $assert(str_contains($html, $needle), 'Workbench content editor is missing: ' . $needle);
    }
    $service = new ContentManagementService($root . '/config/content', $root . '/storage/backups');
    $docs = $service->documents();
    $assert(count($docs) === 4, 'Content manager did not load all four catalogs.');
    return 'Workbench editor controls, API wrappers, and four JSON catalogs are present.';
});


$run('Module registry executes a demonstration module through the shared context', static function () use ($assert, $equal): string {
    $services = new Core\Modules\ServiceContainer();
    $registry = new Core\Modules\ModuleRegistry(new Core\Modules\ModuleContext($services));
    $registry->register(new Core\Modules\Demo\DemoModule());
    $equal(['demo'], $registry->bootAll(), 'Unexpected module boot order.');
    $greeting = $services->get('demo.greeting');
    $equal('Hello, browser QA!', $greeting('browser QA'), 'Demo module service returned an unexpected value.');
    return 'Demo module booted and its injected service executed.';
});
$run('Player workflows boot and reuse the standard application module services', static function () use ($assert, $equal, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-player-module-boot-' . bin2hex(random_bytes(6));
    try {
        $app = new Core\Application();
        $config = ['storage' => ['path' => $dir . '/data'], 'logging' => ['path' => $dir . '/logs/core.log']];
        $order = $app->bootDefaultModules($config);
        $equal(['core.runtime', 'core.universe', 'core.characters', 'core.data-management', 'core.content'], $order, 'Unexpected player workflow module boot order.');
        $assert($app->services()->get('core.storage') instanceof JsonStorage, 'Player workflow did not reuse module storage.');
        $assert($app->services()->get('universe.service') instanceof UniverseService, 'Player workflow universe service was not booted.');
        $assert($app->services()->get('character.service') instanceof CharacterService, 'Player workflow character service was not booted.');
        $assert($app->services()->get('character.universe-assignment') instanceof Core\Modules\Characters\CharacterUniverseAssignmentService, 'Player workflow assignment service was not booted.');
        $equal($order, $app->bootDefaultModules($config), 'Repeated default module boot should be idempotent.');
        $action = (string)file_get_contents(CORE_ROOT . '/player/player-action.php');
        foreach (['bootDefaultModules()', "get('core.storage')", "get('character.service')", "get('universe.service')", "get('character.universe-assignment')"] as $needle) {
            $assert(str_contains($action, $needle), 'Player action does not use shared module service: ' . $needle);
        }
        foreach (['new \\Core\\Storage\\JsonStorage', 'new \\Core\\Modules\\Characters\\CharacterService', 'new \\Core\\Modules\\Universe\\UniverseService', 'new \\Core\\Modules\\Characters\\CharacterUniverseAssignmentService'] as $needle) {
            $assert(!str_contains($action, $needle), 'Player action still constructs a domain service directly: ' . $needle);
        }
        return 'Player character creation and universe assignment use the shared runtime, universe, and character module services.';
    } finally {
        $cleanup($dir);
    }
});

$run('Module registry rejects duplicate module identifiers', static function () use ($assert): string {
    $registry = new Core\Modules\ModuleRegistry(new Core\Modules\ModuleContext(new Core\Modules\ServiceContainer()));
    $registry->register(new Core\Modules\Demo\DemoModule());
    try { $registry->register(new Core\Modules\Demo\DemoModule()); }
    catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'already registered'), 'Unexpected duplicate error.'); return 'Duplicate module name rejected.'; }
    throw new RuntimeException('Duplicate module was accepted.');
});
$run('Module registry rejects missing dependencies', static function () use ($assert): string {
    $module = new class implements Core\Modules\ModuleInterface {
        public function name(): string { return 'browser_needs_base'; }
        public function version(): string { return '1.0.0'; }
        public function dependencies(): array { return ['browser_base_missing']; }
        public function boot(Core\Modules\ModuleContext $context): void {}
    };
    $registry = new Core\Modules\ModuleRegistry(new Core\Modules\ModuleContext(new Core\Modules\ServiceContainer()));
    $registry->register($module);
    try { $registry->bootAll(); }
    catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), "requires missing module 'browser_base_missing'"), 'Unexpected dependency error.'); return 'Missing dependency rejected before boot.'; }
    throw new RuntimeException('Missing dependency was accepted.');
});
$run('Module registry resolves dependency order independent of registration order', static function () use ($assert, $equal): string {
    $order = [];
    $base = new class($order) implements Core\Modules\ModuleInterface {
        public array $order;
        public function __construct(array &$order) { $this->order =& $order; }
        public function name(): string { return 'browser_base'; }
        public function version(): string { return '1.0.0'; }
        public function dependencies(): array { return []; }
        public function boot(Core\Modules\ModuleContext $context): void { $this->order[] = 'browser_base'; }
    };
    $child = new class($order) implements Core\Modules\ModuleInterface {
        public array $order;
        public function __construct(array &$order) { $this->order =& $order; }
        public function name(): string { return 'browser_child'; }
        public function version(): string { return '1.0.0'; }
        public function dependencies(): array { return ['browser_base']; }
        public function boot(Core\Modules\ModuleContext $context): void { $this->order[] = 'browser_child'; }
    };
    $registry = new Core\Modules\ModuleRegistry(new Core\Modules\ModuleContext(new Core\Modules\ServiceContainer()));
    $registry->register($child); $registry->register($base); $registry->bootAll();
    $equal(['browser_base', 'browser_child'], $order, 'Incorrect dependency boot order.');
    return 'Dependencies boot before dependents even when registered in reverse order.';
});
$run('Module registry detects dependency cycles', static function () use ($assert): string {
    $a = new class implements Core\Modules\ModuleInterface {
        public function name(): string { return 'browser_cycle_a'; }
        public function version(): string { return '1'; }
        public function dependencies(): array { return ['browser_cycle_b']; }
        public function boot(Core\Modules\ModuleContext $context): void {}
    };
    $b = new class implements Core\Modules\ModuleInterface {
        public function name(): string { return 'browser_cycle_b'; }
        public function version(): string { return '1'; }
        public function dependencies(): array { return ['browser_cycle_a']; }
        public function boot(Core\Modules\ModuleContext $context): void {}
    };
    $registry = new Core\Modules\ModuleRegistry(new Core\Modules\ModuleContext(new Core\Modules\ServiceContainer()));
    $registry->register($a); $registry->register($b);
    try { $registry->bootAll(); }
    catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'dependency cycle'), 'Unexpected cycle error.'); return 'Circular module dependencies rejected.'; }
    throw new RuntimeException('Dependency cycle was accepted.');
});
$run('Service container rejects duplicate and missing service IDs', static function () use ($assert, $equal): string {
    $services = new Core\Modules\ServiceContainer(); $services->set('browser.value', 7);
    $equal(7, $services->get('browser.value'), 'Registered service did not round-trip.');
    try { $services->set('browser.value', 8); throw new RuntimeException('Duplicate service accepted.'); }
    catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'already registered'), 'Unexpected duplicate service error.'); }
    try { $services->get('browser.missing'); }
    catch (RuntimeException $e) { $assert(str_contains($e->getMessage(), 'not registered'), 'Unexpected missing service error.'); return 'Duplicate and missing service IDs fail explicitly.'; }
    throw new RuntimeException('Missing service was accepted.');
});

$run('Player website, account access, and interactive map controls are present', static function () use ($assert): string {
    $site = file_get_contents(CORE_ROOT . '/player/index.php');
    $account = file_get_contents(CORE_ROOT . '/player/account.php');
    $game = file_get_contents(CORE_ROOT . '/player/game.php');
    $js = file_get_contents(CORE_ROOT . '/player/player.js');
    $assert(is_string($site) && str_contains($site, 'global-nav') && str_contains($site, 'Universes'), 'Public website navigation is missing.');
    $assert(is_string($account) && str_contains($account, 'password_hash') && str_contains($account, 'password_verify'), 'Account registration/login implementation is missing.');
    $assert(is_string($game) && str_contains($game, 'core_user') && str_contains($game, 'travelButton'), 'Player portal authentication gate or travel controls are missing.');
    $assert(is_string($js) && str_contains($js, 'navigation-route.php') && str_contains($js, 'character-travel.php'), 'Interactive travel integration is missing.');
    return 'Public site, account forms, portal gate, system details, and travel controls are present.';
});


$run('Player prototype is separate from the developer Workbench', static function () use ($assert): string {
    $html = file_get_contents(dirname(__DIR__) . '/player/index.php');
    $assert(is_string($html), 'Player prototype HTML could not be read.');
    foreach (['CORE · Procedural Sci-Fi Sandbox', 'global-nav', 'Universes', 'account.php', 'Create account'] as $needle) {
        $assert(str_contains($html, $needle), 'Player prototype is missing marker: ' . $needle);
    }
    return 'Public landing page contains global game navigation, account access, and standard website content.';
});
$run('Player-facing terminology and account security notices match current behavior', static function () use ($assert): string {
    foreach (['index.php', 'account.php', 'character-create.php', 'universe-create.php', 'selection.php', 'game.php'] as $file) {
        $source = file_get_contents(CORE_ROOT . '/player/' . $file);
        $assert(is_string($source) && !preg_match('/frontier/i', $source), 'Prohibited frontier wording remains in player/' . $file);
    }
    $account = file_get_contents(CORE_ROOT . '/player/account.php');
    $assert(is_string($account) && str_contains($account, 'authenticated API writes are protected by session CSRF validation'), 'Account security notice is stale.');
    $game = file_get_contents(CORE_ROOT . '/player/game.php');
    $assert(is_string($game) && !str_contains($game, 'characterCreationScreen'), 'Gameplay still contains duplicate character creation UI.');
    return 'Player-facing wording is consistent, the account security notice reflects implemented controls, and character creation remains a separate workflow.';
});
$run('Player prototype uses Babylon.js and backend entity IDs', static function () use ($assert): string {
    $js = file_get_contents(dirname(__DIR__) . '/player/player.js');
    $game = file_get_contents(dirname(__DIR__) . '/player/game.php');
    $assert(is_string($js), 'Player JavaScript could not be read.');
    $assert(is_string($game), 'Player gameplay page could not be read.');
    foreach (["BABYLON.Engine", "BABYLON.ArcRotateCamera", 'api(`navigation.php?universe_id=', "mesh.metadata={entityId:system.id,entityType:'system'}", 'api(`navigation-route.php?universe_id=', "api('character-travel.php')", 'new ResizeObserver', 'state.engine.resize()', '3D map initialization failed', 'const boot = window.CORE_BOOT || {}'] as $needle) {
        $assert(str_contains($js, $needle), 'Player JavaScript is missing current architecture marker: ' . $needle);
    }
    $assert(str_contains($game, "'universe' => \$playerUniverse") && str_contains($game, "'character' => \$selectedCharacter"), 'Gameplay page must inject the account-owned character and assigned universe.');
    return 'Babylon.js renders primitive system markers mapped to stable backend IDs; gameplay receives the assigned universe and selected character from the authenticated portal and uses navigation/travel APIs.';
});
$run('Release version comes from one central version file', static function () use ($assert): string {
    $versionFile = dirname(__DIR__) . '/config/version.php';
    $version = is_file($versionFile) ? require $versionFile : null;
    $workbench = coreWorkbenchSource(dirname(__DIR__));
    $application = file_get_contents(dirname(__DIR__) . '/app/Application.php');
    $player = file_get_contents(dirname(__DIR__) . '/player/game.php');
    $assert(is_string($version) && preg_match('/^\d+\.\d+\.\d+$/', $version) === 1, 'Central release version file is missing or invalid.');
    $assert(is_string($workbench) && str_contains($workbench, "require __DIR__ . '/config/version.php'") && str_contains($workbench, 'Foundation <?= htmlspecialchars($coreReleaseVersion'), 'Workbench does not use the central release version.');
    $assert(is_string($application) && str_contains($application, "require CORE_ROOT . '/config/version.php'"), 'Application metadata does not use the central release version.');
    $assert(is_string($player) && str_contains($player, "require dirname(__DIR__) . '/config/version.php'") && str_contains($player, 'htmlspecialchars($releaseVersion'), 'Player portal does not use the central release version.');
    return 'Workbench, health API metadata, and player portal read the single config/version.php source.';
});


$run('Player gameplay APIs enforce account ownership and CSRF protection', static function () use ($assert, $cleanup): string {
    $dir = sys_get_temp_dir() . '/core-browser-player-security-' . bin2hex(random_bytes(6));
    $remote = $_SERVER['REMOTE_ADDR'] ?? null;
    try {
        $storage = new JsonStorage($dir);
        $storage->write('characters', 'chr-security-qa', ['id' => 'chr-security-qa', 'owner_account_id' => 'usr-security-owner', 'universe_id' => 'uni-security-qa']);
        $sessionWasActive = session_status() === PHP_SESSION_ACTIVE;
        if (!$sessionWasActive) session_start();
        $sessionSnapshot = $_SESSION;
        $_SERVER['REMOTE_ADDR'] = '203.0.113.17';
        $_SESSION = [];
        $config = ['app' => ['environment' => 'production']];
        $unauthenticated = Core\Http\PlayerApiSecurity::guard(new Core\Http\Request('GET', '/api/characters/record', ['character_id' => 'chr-security-qa']), $storage, $config);
        $assert($unauthenticated instanceof Core\Http\Response && $unauthenticated->statusCode() === 401, 'Unauthenticated character read was not rejected.');
        $_SESSION = ['core_user' => ['id' => 'usr-security-other'], 'core_csrf' => 'qa-csrf-token'];
        $crossAccount = Core\Http\PlayerApiSecurity::guard(new Core\Http\Request('GET', '/api/characters/record', ['character_id' => 'chr-security-qa']), $storage, $config);
        $assert($crossAccount instanceof Core\Http\Response && $crossAccount->statusCode() === 404, 'Cross-account character read was not hidden.');
        $crossUniverseCreate = Core\Http\PlayerApiSecurity::guard(new Core\Http\Request('POST', '/api/characters', [], ['X-CORE-CSRF' => 'qa-csrf-token'], '{"universe_id":"uni-security-qa","name":"Intruder"}'), $storage, $config);
        $assert($crossUniverseCreate instanceof Core\Http\Response && $crossUniverseCreate->statusCode() === 404, 'Character creation into another account universe was not denied.');
        $noCsrf = Core\Http\PlayerApiSecurity::guard(new Core\Http\Request('POST', '/api/characters/scan', [], [], '{"character_id":"chr-security-qa"}'), $storage, $config);
        $assert($noCsrf instanceof Core\Http\Response && $noCsrf->statusCode() === 403, 'Write without CSRF token was accepted.');
        $_SESSION['core_user']['id'] = 'usr-security-owner';
        $valid = Core\Http\PlayerApiSecurity::guard(new Core\Http\Request('POST', '/api/characters/scan', [], ['X-CORE-CSRF' => 'qa-csrf-token'], '{"character_id":"chr-security-qa"}'), $storage, $config);
        $assert($valid === null, 'Owned character write with valid CSRF token was rejected.');
        return 'Unauthenticated and cross-account reads are denied; mutating requests require a valid session CSRF token.';
    } finally {
        if (session_status() === PHP_SESSION_ACTIVE) { $_SESSION = $sessionSnapshot ?? []; if (empty($sessionWasActive)) session_write_close(); }
        if ($remote === null) unset($_SERVER['REMOTE_ADDR']); else $_SERVER['REMOTE_ADDR'] = $remote;
        $cleanup($dir);
    }
});
$run('Account archival preserves account identity and is idempotent', static function () use ($assert, $equal): string {
    $accounts = ['usr-archive-qa' => ['id' => 'usr-archive-qa', 'email' => 'archive@example.test', 'password_hash' => 'qa-hash', 'status' => 'active']];
    $archived = Core\Modules\Accounts\PlayerAccountArchiveService::archive($accounts, 'usr-archive-qa', '2026-11-10T12:00:00+00:00');
    $equal('disabled', $archived['usr-archive-qa']['status'], 'Archived account must not remain active.');
    $equal('archive@example.test', $archived['usr-archive-qa']['email'], 'Account identity was not preserved.');
    $equal('qa-hash', $archived['usr-archive-qa']['password_hash'], 'Account credential hash was not preserved.');
    $equal('2026-11-10T12:00:00+00:00', $archived['usr-archive-qa']['archived_at'], 'Archive timestamp was not saved.');
    $again = Core\Modules\Accounts\PlayerAccountArchiveService::archive($archived, 'usr-archive-qa', '2026-11-11T12:00:00+00:00');
    $equal('2026-11-10T12:00:00+00:00', $again['usr-archive-qa']['archived_at'], 'Repeated archive changed the original timestamp.');
    return 'Account record and credential remain intact, sign-in is disabled, and repeated archival is idempotent.';
});
$run('Account administration exposes archive rather than permanent deletion', static function () use ($assert): string {
    $api = file_get_contents(dirname(__DIR__) . '/api/player-accounts-admin.php');
    $ui = file_get_contents(dirname(__DIR__) . '/admin/player-account.php');
    $assert(is_string($api) && str_contains($api, 'PlayerAccountArchiveService::archive'), 'Account API does not call the archive service.');
    $assert(is_string($ui) && str_contains($ui, "request('archive')") && str_contains($ui, 'Archive account'), 'Account UI does not expose archive action.');
    $assert(!str_contains((string)$ui, 'Permanently delete this account'), 'Account UI still offers permanent deletion.');
    return 'The administration UI archives accounts and preserves ownership references.';
});

$run('Gameplay client sends session CSRF token with write requests', static function () use ($assert): string {
    $game = file_get_contents(dirname(__DIR__) . '/player/game.php');
    $js = file_get_contents(dirname(__DIR__) . '/player/player.js');
    $assert(is_string($game) && str_contains($game, 'data-csrf-token='), 'Gameplay page does not expose the session CSRF token to its own client.');
    $assert(is_string($js) && str_contains($js, "headers['X-CORE-CSRF']") && str_contains($js, 'document.body.dataset.csrfToken'), 'Gameplay API helper does not attach the CSRF header.');
    return 'Gameplay write requests include the session token in X-CORE-CSRF.';
});
$run('Player character collection is account-scoped outside the trusted Workbench', static function () use ($assert): string {
    $application = file_get_contents(dirname(__DIR__) . '/app/Application.php');
    $security = file_get_contents(dirname(__DIR__) . '/app/Http/PlayerApiSecurity.php');
    $assert(is_string($application) && str_contains($application, "owner_account_id'] ?? '') === \$accountId"), 'Character listing does not filter records by the signed-in account.');
    $assert(is_string($security) && str_contains($security, 'ownsCharacter') && str_contains($security, 'ownsUniverse'), 'Central ownership checks are missing.');
    return 'Character collection responses are filtered to the signed-in account; universe navigation and lifecycle operations require an owned character.';
});


$run('Character preview wraps and rotates the complete imported GLB rig toward the camera', static function () use ($assert): string {
    $creation = (string)file_get_contents(dirname(__DIR__) . '/player/character-preview.js');
    $roster = (string)file_get_contents(dirname(__DIR__) . '/player/character-roster-preview.js');
    foreach ([$creation, $roster] as $index => $js) {
        $assert(str_contains($js, 'result.transformNodes || []'), 'Preview ' . $index . ' omits imported transform nodes.');
        $assert(str_contains($js, 'new BABYLON.TransformNode('), 'Preview ' . $index . ' does not wrap the complete rig.');
        $assert(str_contains($js, 'modelRoot.rotation.y += Math.PI'), 'Preview ' . $index . ' does not turn the known +Z model front toward its -Z camera.');
    }
    return 'Both preview modes rotate all imported GLB roots as one rig.';
});
$run('System overview orbit tubes and planets share one local inclined plane', static function () use ($assert): string {
    $js = (string)file_get_contents(dirname(__DIR__) . '/player/system-view.js');
    $assert(str_contains($js, 'BABYLON.MeshBuilder.CreateTube(`orbit-${index}`'), 'System orbit is not built from explicit path geometry.');
    $assert(str_contains($js, 'window.CORE_ORBITS.layout'), 'System view does not use the shared orbital layout.');
    $assert(!str_contains($js, 'plane.rotation'), 'System view still invents inclined orbital planes.');
    $assert(!str_contains($js, 'orbit.rotation.x = Math.PI / 2'), 'System orbit has an independent plane rotation.');
    return 'The orbit tube and animated planet use the shared coplanar orbital layout.';
});
$run('Character selection location preview aligns every planet with its inclined orbit', static function () use ($assert): string {
    $js = (string)file_get_contents(dirname(__DIR__) . '/player/character-roster-preview.js');
    $assert(str_contains($js, 'window.CORE_ORBITS.layout'), 'Location preview does not use the shared orbital layout.');
    $assert(str_contains($js, 'BABYLON.MeshBuilder.CreateTube'), 'Location preview does not use explicit orbit path geometry.');
    $assert(!str_contains($js, 'plane.rotation'), 'Location preview still invents inclined orbital planes.');
    $assert(!str_contains($js, 'Math.sin(angle) * orbit * .42'), 'Location planet still uses a flattened elliptical path.');
    return 'Location preview uses the same shared coplanar orbital layout as the system view.';
});

$run('Character roster portrait selects the exact Walk animation', static function () use ($assert): string {
    $js = (string)file_get_contents(dirname(__DIR__) . '/player/character-roster-preview.js');
    $assert(str_contains($js, "String(group.name || '').trim().toLowerCase() === 'walk'"), 'Portrait does not select the exact Walk clip.');
    $assert(!str_contains($js, 'find((group) => /walk/i.test(group.name))'), 'Portrait still uses broad matching that can select Crouch_Walk.');
    return 'The roster portrait selects Walk by exact clip name.';
});

$run('Character selection and system view load the shared orbital mechanics helper', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $helper = (string)file_get_contents($root . '/player/orbital-mechanics.js');
    $selection = (string)file_get_contents($root . '/player/selection.php');
    $deletion = (string)file_get_contents($root . '/app/Modules/UniverseDeletionService.php');
    $game = (string)file_get_contents($root . '/player/game.php');
    $assert(str_contains($helper, 'window.CORE_ORBITS'), 'Shared orbital helper is missing.');
    $assert(str_contains($selection, '/orbital-mechanics.js'), 'Character selection does not load orbital mechanics.');
    $assert(str_contains($game, '/orbital-mechanics.js'), 'Gameplay does not load orbital mechanics.');
    return 'Both interfaces load the same shared orbital calculations.';
});

$run('Character creation persists and validates the selected appearance tint', static function () use ($assert, $equal): string {
    $dir = sys_get_temp_dir() . '/core-api-appearance-' . bin2hex(random_bytes(6));
    try {
        $storage = new JsonStorage($dir);
        $service = new CharacterService($storage);
        $character = $service->create('', 'Tint QA Pilot', 'explorer', 'human', [], 'tint-qa-owner', null, ['tint' => '#b64e91']);
        $equal('#b64e91', $character['appearance']['tint'] ?? null, 'Selected tint was not saved for an unassigned character.');
        $universe = (new UniverseService($storage))->createOrLoad('core-api-appearance-tint-assigned');
        $assigned = $service->create($universe['id'], 'Assigned Tint QA', 'explorer', 'human', [], 'tint-qa-owner', null, ['tint' => '#31a7d2']);
        $equal('#31a7d2', $assigned['appearance']['tint'] ?? null, 'Selected tint was not saved for an assigned character.');
        return 'Valid six-digit hex tints persist for both unassigned and universe-assigned character records.';
    } finally {
        if (is_dir($dir)) { $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST); foreach ($it as $item) $item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname()); rmdir($dir); }
    }
});
$run('Blank test world validates character, universe, current system, and generated world', static function () use ($assert): string {
    $page = (string)file_get_contents(dirname(__DIR__) . '/player/world.php');
    $client = (string)file_get_contents(dirname(__DIR__) . '/player/world.js');
    $environment = (string)file_get_contents(dirname(__DIR__) . '/player/planetary-environment.js');
    $game = (string)file_get_contents(dirname(__DIR__) . '/player/game.php');
    foreach (['owner_account_id', 'CharacterLifecycleGuard::assertCanPerformGameplayAction', 'UniverseLifecycleGuard::assertCanPerformGameplayAction', '$systemId !== $currentSystemId', 'WorldGenerator())->generateForSystem'] as $needle) {
        $assert(str_contains($page, $needle), 'Test-world server validation is missing: ' . $needle);
    }
    foreach (['keydown', 'keyup', 'camera.getDirection(BABYLON.Axis.Z)', 'speedWalk', 'SceneLoader.ImportMeshAsync', 'CORE_PLANETARY_ENVIRONMENT.create(scene)', 'CORE_PLANETARY_ENVIRONMENT.moveOnSurface'] as $needle) {
        $assert(str_contains($client, $needle), 'Test-world client behavior is missing: ' . $needle);
    }
    $assert(str_contains($environment, 'core-planetary-terrain'), 'Spherical planetary terrain mesh integration is missing.');
    $assert(str_contains($game, 'id="enterWorldButton"'), 'System inspector does not expose the test-world entry button.');
    return 'The test world is seeded from a verified generated world, renders the spherical planetary terrain, and supports third-person WASD movement.';
});
$run('Planetary terrain uses broad landforms with expanded plains and bounded relief', static function () use ($assert): string {
    $environment = (string)file_get_contents(dirname(__DIR__) . '/player/planetary-environment.js');
    $generator = (string)file_get_contents(dirname(__DIR__) . '/app/Modules/Universe/PlanetaryTerrainGenerator.php');
    $assert(str_contains($environment, 'let localPatchSizeKm = 512;'), 'Local terrain relief patch is not expanded to 512 km.');
    $assert(str_contains($environment, 'const localPatchSegments = 320;'), 'Local terrain patch resolution is not 320 segments.');
    $assert(str_contains($environment, 'normal.x * 80 + 41.7'), 'Broad regional landform field is missing.');
    $assert(str_contains($environment, 'normal.x * 200 + 7.4'), 'Rolling regional landform field is missing.');
    $assert(str_contains($environment, 'normal.x * 470 + 18.6'), 'Fine landform field is missing.');
    $assert(str_contains($environment, "const detailStrength = terrain === 'mountains' ? 8.0 : (terrain === 'hills' ? 4.5 : 2.2);"), 'Terrain relief amplitudes do not provide visible plains, hills, and mountain variation.');
    $assert(str_contains($environment, 'Math.cos(6 / planetRadius)'), 'Local terrain patch still recenters too frequently during player movement.');
    $assert(str_contains($environment, 'const segments = 128;'), 'Distant planet fallback mesh is not using the lightweight tessellation.');
    $assert(str_contains($environment, 'function hashTerrainSeed(seed)'), 'Persistent WLD-/SYS-prefixed terrain seeds must be hashed as full strings.');
    $assert(str_contains($environment, 'const landform = 0.55 + broadDetail * 0.62'), 'Local patch relief must remain visible above the coarse sphere surface.');
    $assert(str_contains($worldClient = (string)file_get_contents(dirname(__DIR__) . '/player/world.js'), 'camera.maxZ = Math.max(250000'), 'Planetary camera far plane is not extended beyond the local terrain horizon.');
    $assert(str_contains($environment, '0.82'), 'Mountain classification threshold is not raised to preserve broad plains.');
    $assert(str_contains($environment, 'Number(terrainParameters.relief_exaggeration) || 2.5, 1.0, 2.75'), 'Legacy relief exaggeration is not bounded to the gentler range.');
    $assert(str_contains($generator, "'relief_exaggeration' => 2.5"), 'New terrain records do not persist the gentler relief setting.');
    $assert(str_contains($environment, 'elevation *= reliefExaggeration;'), 'Terrain sampling does not share relief scaling between geometry, movement, spawn, and altitude.');
    return 'A horizon-spanning 320-subdivision local patch uses broad, measurable landform relief, a lightweight distant sphere, and movement-throttled terrain updates.';
});
$run('Planetary character visual root is grounded independently of the movement root', static function () use ($assert): string {
    $worldClient = (string)file_get_contents(dirname(__DIR__) . '/player/world.js');
    $assert(str_contains($worldClient, 'let playerVisualRoot = null;'), 'Character visual-root transform is missing.');
    $assert(str_contains($worldClient, 'playerVisualRoot.position.y -= Number.isFinite(bounds.min.y) ? bounds.min.y : 0;'), 'Character feet are not offset in local up space with finite-bound protection.');
    $assert(str_contains($worldClient, 'importedRoots.forEach(node => { node.parent = playerVisualRoot; });'), 'Imported character nodes are not parented under the grounded visual root.');
    $assert(!str_contains($worldClient, 'playerRoot.position.y -= Number.isFinite(bounds.min.y)'), 'World-space Y offset that is lost during planetary movement remains.');
    return 'Character model bounds are normalized in local up-space, so the feet remain at the sampled planetary surface after root movement and rotation.';
});
$run('Planetary character orientation uses supported Babylon.js quaternion APIs', static function () use ($assert): string {
    $worldClient = (string)file_get_contents(dirname(__DIR__) . '/player/world.js');
    $assert(str_contains($worldClient, 'function alignUpToSurface(normal)'), 'Planetary surface alignment helper is missing.');
    $assert(str_contains($worldClient, 'BABYLON.Quaternion.RotationAxis'), 'Surface alignment does not use a supported Babylon.js quaternion factory.');
    $assert(!str_contains($worldClient, 'BABYLON.Quaternion.FromUnitVectors'), 'Unsupported Quaternion.FromUnitVectors call remains in the world client.');
    return 'Player and remote avatars align their local up axis to the planetary surface normal using supported Babylon.js quaternion operations.';
});
$run('Selected character tint is rendered consistently in roster and test world', static function () use ($assert): string {
    $selection = (string)file_get_contents(dirname(__DIR__) . '/player/selection.php');
    $roster = (string)file_get_contents(dirname(__DIR__) . '/player/character-roster-preview.js');
    $world = (string)file_get_contents(dirname(__DIR__) . '/player/world.js');
    $assert(str_contains($selection, 'data-tint='), 'Roster card does not expose the saved tint.');
    $assert(str_contains($roster, 'canvas.dataset.tint'), 'Roster preview does not apply the saved tint.');
    $assert(str_contains($world, 'boot.character.appearance?.tint'), 'Test world does not apply the saved tint.');
    return 'The saved character tint is carried into both selection preview and spawned character rendering.';
});


$run('Borderless interface contract removes component border declarations across all shared stylesheets', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $shared = (string)file_get_contents($root . '/assets/borderless.css');
    $assert(str_contains($shared, 'border: 0 !important'), 'The central borderless contract is missing its universal reset.');
    $assert(str_contains($shared, '*::before'), 'Pseudo-elements are not covered by the borderless contract.');
    $assert(str_contains($shared, '::-webkit-slider-thumb'), 'Browser-native form-control parts are not covered.');
    foreach (['assets/admin.css', 'assets/admin-player-account.css', 'player/player.css', 'player/world.css', 'player/system-view.css'] as $relative) {
        $css = (string)file_get_contents($root . '/' . $relative);
        $assert(preg_match('/(?<![a-z-])border(?:-(?:top|right|bottom|left|width|style|color|image))?\s*:/i', $css) !== 1, 'A component border declaration remains in ' . $relative . '.');
    }
    $assert(!str_contains((string)file_get_contents($root . '/player/player.css'), 'box-shadow:inset 0 -2px'), 'The current workflow step still draws a border-like inset stripe.');
    return 'All shared UI stylesheets are free of component border declarations; one central contract handles browser defaults.';
});

$run('Every CORE HTML surface loads the cache-busted borderless stylesheet last', static function () use ($assert): string {
    $root = dirname(__DIR__);
    foreach (['index.php', 'player/index.php', 'player/account.php', 'player/selection.php', 'player/character-create.php', 'player/universe-create.php', 'player/game.php', 'player/world.php', 'admin/player-account.php'] as $relative) {
        $page = (string)file_get_contents($root . '/' . $relative);
        $globalPosition = strrpos($page, 'borderless.css?v=');
        $lastStylesheetPosition = strrpos($page, 'rel="stylesheet"');
        $assert($globalPosition !== false, 'The borderless stylesheet is not loaded by ' . $relative . '.');
        $assert($lastStylesheetPosition !== false && $globalPosition > $lastStylesheetPosition, 'The borderless stylesheet is not the final stylesheet in ' . $relative . '.');
    }
    return 'All nine HTML surfaces load the versioned borderless stylesheet after their other CSS.';
});

$run('Standalone account administration uses external CSS and preserves keyboard focus indicators', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $page = (string)file_get_contents($root . '/admin/player-account.php');
    $css = (string)file_get_contents($root . '/assets/admin-player-account.css');
    $global = (string)file_get_contents($root . '/assets/borderless.css');
    $assert(!str_contains($page, '<style>'), 'Standalone account administration still embeds its stylesheet.');
    $assert(str_contains($page, 'admin-player-account.css?v='), 'Standalone account administration does not load its external stylesheet.');
    $assert(str_contains($global, ':focus-visible'), 'The shared borderless stylesheet does not preserve keyboard focus visibility.');
    $assert(str_contains($css, 'button:focus-visible'), 'Standalone account administration has no keyboard focus styling.');
    return 'Standalone account styling is external and keyboard focus remains visible.';
});


$run('Colyseus 0.16 foundation preserves CORE identity and server-authoritative movement boundaries', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $package = json_decode((string)file_get_contents($root . '/multiplayer/package.json'), true);
    $identity = (string)file_get_contents($root . '/multiplayer/src/contracts/MultiplayerIdentity.ts');
    $room = (string)file_get_contents($root . '/multiplayer/src/contracts/RoomIdentity.ts');
    $movement = (string)file_get_contents($root . '/multiplayer/src/contracts/MovementProtocol.ts');
    $architecture = (string)file_get_contents($root . '/multiplayer/ARCHITECTURE.md');
    $assert(is_array($package) && str_starts_with((string)($package['dependencies']['@colyseus/core'] ?? ''), '^0.16.'), 'Colyseus core dependency is not on the 0.16-compatible line.');
    $assert(!isset($package['dependencies']['colyseus']) && !isset($package['dependencies']['@colyseus/auth']), 'Umbrella Colyseus/auth dependency would restore vulnerable OAuth dependencies.');
    $assert(($package['overrides']['@colyseus/core']['nanoid'] ?? '') === '^3.3.18', 'NanoID override does not meet the patched 3.3.18 floor.');
    $assert(str_contains($identity, 'universeSeed') && str_contains($identity, 'universeId'), 'Saved universe ID and deterministic seed are not separate identity claims.');
    $assert(str_contains($room, 'locationId: string | null'), 'Room key does not account for CORE location-model readiness.');
    $assert(str_contains($movement, 'Client-to-server movement intent') && str_contains($movement, 'AuthoritativePlayerTransform'), 'Movement protocol does not separate client input from server transforms.');
    $assert(str_contains($architecture, 'Production joins require') && str_contains($architecture, 'HMAC-SHA256 grant'), 'Production authentication boundary is not documented.');
    return 'The multiplayer contracts remain intact; the Colyseus room service is active while production joins remain blocked pending PHP grants.';
});

$run('Colyseus 0.16 server exposes protected universe room lifecycle and health checks', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $package = json_decode((string)file_get_contents($root . '/multiplayer/package.json'), true);
    $server = (string)file_get_contents($root . '/multiplayer/src/server.ts');
    $room = (string)file_get_contents($root . '/multiplayer/src/rooms/UniverseRoom.ts');
    $config = (string)file_get_contents($root . '/multiplayer/src/config/runtime.ts');
    $identity = (string)file_get_contents($root . '/multiplayer/src/contracts/RoomIdentity.ts');
    $assert(($package['version'] ?? '') === '0.1.115', 'Multiplayer package version is not 0.1.115.');
    $assert(str_starts_with((string)($package['dependencies']['@colyseus/core'] ?? ''), '^0.16.'), 'Colyseus core version is not 0.16-compatible.');
    $assert(str_contains($server, 'new Server(') && str_contains($server, 'createServer(app)') && str_contains($server, 'server.listen(config.port, config.host)'), 'Colyseus process startup is missing.');
    $assert(str_contains($server, 'new WebSocketTransport(') && str_contains($server, 'pingInterval: 10000') && str_contains($server, 'pingMaxRetries: 2'), 'WebSocket transport options are not configured on the transport instance.');
    $assert(str_contains($server, 'filterBy(["universeId", "systemId", "locationId"])'), 'Room matchmaking keys are incomplete.');
    foreach (['onCreate(', 'onAuth(', 'onJoin(', 'onLeave(', 'onDispose(', 'setMetadata('] as $needle) {
        $assert(str_contains($room, $needle), 'Room lifecycle is missing ' . $needle . '.');
    }
    $assert(str_contains($room, 'playerPresence') && str_contains($room, 'client.sessionId'), 'Room does not track transient server-side presence.');
    $assert(str_contains($room, 'setSimulationInterval') && str_contains($room, 'player-transforms') && str_contains($room, 'parseMovementInput'), 'Room does not simulate and broadcast server-authoritative movement.');
    $assert(str_contains($config, "nodeEnvironment !== 'production'") && str_contains($config, 'isLoopbackHost') && str_contains($config, 'developmentToken.length >= 32'), 'Development guest mode is not sufficiently constrained.');
    $assert(str_contains($identity, 'normalizeRoomIdentity') && str_contains($identity, 'JSON.stringify'), 'Room identity validation is missing.');
    $assert(str_contains($server, '"/health"') && str_contains($server, '"php-hmac-grant"'), 'Health endpoint does not expose the expected service status.');
    return 'The Colyseus process, system-level room matching, protected local development join mode, transient presence, and health endpoint are defined.';
});

$run('Babylon gameplay exposes authenticated Colyseus presence connection controls', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $page = (string)file_get_contents($root . '/player/game.php');
    $client = (string)file_get_contents($root . '/player/player.js');
    $assert(str_contains($page, 'colyseus.js@0.16.22'), 'Pinned Colyseus browser SDK is missing.');
    $assert(str_contains($page, 'CORE_MULTIPLAYER_PUBLIC_URL') && str_contains($page, 'data-multiplayer-url'), 'Public multiplayer URL configuration is missing.');
    $assert(str_contains($page, 'id="multiplayerConnectButton"') && str_contains($page, 'id="multiplayerStatus"'), 'Multiplayer controls are missing.');
    $assert(str_contains($client, "api('multiplayer/token')") && str_contains($client, 'client.auth.token = grant.token'), 'PHP grant acquisition or SDK token assignment is missing.');
    $assert(str_contains($client, "joinOrCreate('universe'") && str_contains($client, 'refreshMultiplayerSystemRoom'), 'Universe room join or system migration is missing.');
    return 'The Babylon gameplay page can request a short-lived PHP grant, join its authorized universe/system room, and leave or migrate the session safely.';
});


$run('Planetary test world connects to a location-bound authoritative movement room', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $page = (string)file_get_contents($root . '/player/world.php');
    $client = (string)file_get_contents($root . '/player/world.js');
    $application = (string)file_get_contents($root . '/app/Application.php');
    $assert(str_contains($page, 'colyseus.js@0.16.22') && str_contains($page, 'worldMultiplayerStatus'), 'World page is missing its multiplayer SDK or status.');
    $assert(str_contains($client, "joinOrCreate('universe'") && str_contains($client, 'world_id: boot.world.id'), 'World client does not request and join a location-bound room.');
    $assert(str_contains($client, "send('move'") && str_contains($client, 'player-transforms'), 'World client does not send movement input and receive authoritative transforms.');
    $assert(str_contains($application, 'generateForSystem') && str_contains($application, "'locationId' => \$locationId"), 'PHP does not validate generated world membership in the authorization grant.');
    return 'The world client joins a PHP-authorized world room and uses server-simulated movement transforms.';
});

$run('CORE 0.1.115 shared universe visits preserve home universe and expose independent system/world seeds', static function () use ($assert): string {
    $root = dirname(__DIR__);
    $application = (string)file_get_contents($root . '/app/Application.php');
    $shared = (string)file_get_contents($root . '/app/Modules/Universe/SharedUniverseService.php');
    $context = (string)file_get_contents($root . '/app/Modules/Characters/CharacterUniverseContext.php');
    $systemGenerator = (string)file_get_contents($root . '/app/Modules/Universe/UniverseGenerator.php');
    $worldGenerator = (string)file_get_contents($root . '/app/Modules/Universe/WorldGenerator.php');
    $selection = (string)file_get_contents($root . '/player/selection.php');
    $deletion = (string)file_get_contents($root . '/app/Modules/UniverseDeletionService.php');
    $assert(str_contains($application, "'/api/universe/share'") && str_contains($application, "'/api/universe/visit'") && str_contains($application, "'/api/universe/leave'"), 'Shared-universe API routes are incomplete.');
    $assert(str_contains($shared, 'code_hash') && str_contains($shared, 'home_location_snapshot') && str_contains($shared, 'active_universe_id'), 'Share-code hashing or reversible home-universe visit state is missing.');
    $assert(str_contains($context, 'activeUniverseId') && str_contains($context, 'isVisiting'), 'Character active-universe resolution is missing.');
    $assert(str_contains($systemGenerator, "\$systemSeed = 'SYS-'") && str_contains($systemGenerator, "'seed' => \$systemSeed") && str_contains($worldGenerator, "\$worldSeed = 'WLD-'") && str_contains($worldGenerator, "'seed' => \$worldSeed"), 'Hierarchical system/world seed generation is incomplete.');
    $assert(str_contains($selection, 'sharedUniverseVisitForm') && str_contains($selection, 'shared-universe-share') && str_contains($selection, 'shared-universe-leave'), 'Character selection does not expose share, visit, and return controls.');
    $assert(str_contains($deletion, 'activeVisitorsFor'), 'Universe deletion does not guard against active visitors.');
    return 'Share-code visitation preserves permanent home identity and exposes independent procedural system/world seeds.';
});



$run('CORE 0.1.165 moon presentation frame follows the active camera orientation', static function () use ($assert): string {
    $astronomy = (string)file_get_contents(CORE_ROOT . '/player/astronomical-environment.js');
    $assert(str_contains($astronomy, 'const orbitForward = (this.orbitForward || BABYLON.Axis.Z).clone().normalize();'), 'Moon orbit must use the established planet-fixed forward axis.');
    $assert(str_contains($astronomy, 'const orbitRight = (this.orbitRight || BABYLON.Axis.X).clone().normalize();'), 'Moon orbit must use the established planet-fixed right axis.');
    $assert(str_contains($astronomy, 'moon.mesh.position.copyFrom(planetCenter.add(moonDirection.scale(orbitalRadius)))'), 'Moon position must remain planet-centered and independent of camera heading.');
    $assert(str_contains($astronomy, 'if (moon.orbitMesh && !moon.orbitGeometryInitialized)'), 'Static moon orbit geometry must not be rebuilt every render frame.');
    $assert(str_contains($astronomy, 'moon.orbitGeometryInitialized = true;'), 'Moon orbit geometry initialization must be tracked.');
    $assert(!str_contains($astronomy, 'moonSkyBasis.forward.scale(Math.cos(orbitalAngle))'), 'Obsolete camera-relative moon placement must not return.');
    return 'Moon placement remains anchored to the fixed planetary orbital frame; camera movement does not redefine orbital positions.';
});

$passed = count(array_filter($results, static fn(array $r): bool => $r['status'] === 'PASS'));
$failed = count($results) - $passed;
http_response_code($failed === 0 ? 200 : 500);

echo json_encode(['ok' => $failed === 0, 'application' => 'CORE', 'version' => require dirname(__DIR__) . '/config/version.php', 'passed' => $passed, 'failed' => $failed, 'results' => $results], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
