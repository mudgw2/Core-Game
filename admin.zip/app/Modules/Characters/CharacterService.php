<?php
declare(strict_types=1);

namespace Core\Modules\Characters;

use Core\Modules\Universe\UniverseLifecycleGuard;

use Core\Storage\JsonStorage;
use Core\Modules\Universe\NavigationGraph;
use RuntimeException;

/** Development-stage character records linked to a persisted universe. */
final class CharacterService
{
    public function __construct(private JsonStorage $storage) {}

    public function create(string $universeId, string $name, string $role = 'Explorer', string $speciesId = 'human', array $attributes = [], ?string $ownerAccountId = null, ?string $humanBonusAttribute = null, array $appearance = [], ?array $background = null): array
    {
        $universeId = trim($universeId);
        $name = trim($name);
        $role = trim($role);
        $options = CharacterCreationRules::definitions();
        $roles = is_array($options['roles'] ?? null) ? $options['roles'] : [];
        $roleDefinition = null;
        foreach ($roles as $entry) { if (is_array($entry) && (($entry['id'] ?? null) === $role || ($entry['label'] ?? null) === $role)) { $roleDefinition = $entry; break; } }
        if ($roleDefinition === null) throw new RuntimeException('Select a valid character role from the available options.');
        $speciesId = trim($speciesId);
        $creation = CharacterCreationRules::validate($options, $speciesId, $attributes, $humanBonusAttribute);
        $speciesDefinition = null;
        foreach (($options['species'] ?? []) as $entry) { if (is_array($entry) && ($entry['id'] ?? null) === $speciesId) { $speciesDefinition = $entry; break; } }
        if ($speciesDefinition === null) throw new RuntimeException('Select a valid character species from the available options.');
        $backgroundSnapshot = $background !== null ? self::validateBackgroundSnapshot($background, $speciesId) : null;
        $baseAttributes = $creation['base_attributes'];
        $validatedAttributes = $creation['attributes'];
        $tint = strtolower(trim((string)($appearance['tint'] ?? '#61d8e8')));
        if (!preg_match('/^#[0-9a-f]{6}$/', $tint)) $tint = '#61d8e8';
        $saturation = filter_var($appearance['saturation'] ?? 100, FILTER_VALIDATE_INT);
        if ($saturation === false || $saturation < 0 || $saturation > 200) $saturation = 100;
        $brightness = filter_var($appearance['brightness'] ?? 100, FILTER_VALIDATE_INT);
        if ($brightness === false || $brightness < 50 || $brightness > 150) $brightness = 100;
        $savedAppearance = ['version' => 1, 'tint' => $tint, 'saturation' => $saturation, 'brightness' => $brightness];
        $role = (string)$roleDefinition['label'];
        if ($name === '') throw new RuntimeException('Character name cannot be empty.');
        $nameLength = preg_match_all('/./us', $name);
        if ($nameLength === false || $nameLength < 2 || $nameLength > 40) {
            throw new RuntimeException('Character name must be between 2 and 40 characters.');
        }
        $roleLength = preg_match_all('/./us', $role);
        if ($role === '' || $roleLength === false || $roleLength > 40) {
            throw new RuntimeException('Character role must be a non-empty string of at most 40 characters.');
        }
        // Unassigned characters are valid persistent identities. They deliberately have no
        // location/exploration state and cannot enter gameplay until safely assigned later.
        if ($universeId === '') {
            $id = 'chr_' . bin2hex(random_bytes(12));
            $now = gmdate('c');
            $record = [
                'id' => $id, 'schema_version' => 1, 'universe_id' => null, 'owner_account_id' => $ownerAccountId,
                'name' => $name, 'role' => (string)$roleDefinition['label'],
                'role_id' => (string)$roleDefinition['id'],
                'species_id' => (string)$speciesDefinition['id'],
                'species' => (string)$speciesDefinition['label'],
                'attributes' => $validatedAttributes,
                'base_attributes' => $baseAttributes,
                'species_adjustments' => $creation['species_adjustments'],
                'ability_points_spent' => $creation['ability_points_spent'],
                'ability_point_budget' => $creation['ability_point_budget'],
                'human_bonus_attribute' => $creation['human_bonus_attribute'],
                'appearance' => $savedAppearance,
                'age' => $backgroundSnapshot['age'] ?? null,
                'background' => $backgroundSnapshot,
                'lifecycle' => ['enabled' => true, 'locked' => false, 'updated_at' => $now, 'last_action' => 'created_unassigned'],
                'location' => null, 'current_system_id' => null, 'current_constellation_id' => null,
                'created_at' => $now, 'revision' => 0,
            ];
            return $this->storage->createIfAbsent('characters', $id, $record);
        }
        // Character creation shares the universe lock with universe deletion. This closes the race
        // where a new dependent character could appear after deletion enumerates its dependents.
        return $this->storage->withRecordLockOperation('universes', $universeId, function () use ($universeId, $name, $role, $roleDefinition, $speciesDefinition, $validatedAttributes, $baseAttributes, $creation, $savedAppearance, $ownerAccountId, $backgroundSnapshot): array {
            $universe = $this->storage->read('universes', $universeId);
            if ($universe === null || ($universe['id'] ?? null) !== $universeId) {
                throw new RuntimeException('The selected universe does not exist.');
            }
            UniverseLifecycleGuard::assertCanPerformGameplayAction($universe);
            $id = 'chr_' . bin2hex(random_bytes(12));
            $firstSystem = $universe['baseline']['systems'][0] ?? null;
            if (!is_array($firstSystem) || !isset($firstSystem['id'])) {
                throw new RuntimeException('The selected universe has no valid starting system.');
            }
            $now = gmdate('c');
            $record = [
                'id' => $id,
                'schema_version' => 1,
                'universe_id' => $universeId,
                'owner_account_id' => $ownerAccountId,
                'name' => $name,
                'role' => $role,
                'role_id' => (string)$roleDefinition['id'],
                'species_id' => (string)$speciesDefinition['id'],
                'species' => (string)$speciesDefinition['label'],
                'attributes' => $validatedAttributes,
                'base_attributes' => $baseAttributes,
                'species_adjustments' => $creation['species_adjustments'],
                'ability_points_spent' => $creation['ability_points_spent'],
                'ability_point_budget' => $creation['ability_point_budget'],
                'human_bonus_attribute' => $creation['human_bonus_attribute'],
                'appearance' => $savedAppearance,
                'age' => $backgroundSnapshot['age'] ?? null,
                'background' => $backgroundSnapshot,
                'lifecycle' => ['enabled' => true, 'locked' => false, 'updated_at' => $now, 'last_action' => 'created'],
                'current_system_id' => (string)$firstSystem['id'],
                'current_constellation_id' => (string)($firstSystem['constellation_id'] ?? ''),
                'location' => [
                    'constellation_id' => (string)($firstSystem['constellation_id'] ?? ''),
                    'system_id' => (string)$firstSystem['id'],
                    'updated_at' => $now,
                ],
                'exploration' => [
                    'explored_systems' => [[
                        'system_id' => (string)$firstSystem['id'],
                        'name' => (string)($firstSystem['name'] ?? $firstSystem['id']),
                        'first_visited_at' => $now,
                        'first_visited_revision' => 0,
                    ]],
                ],
                'created_at' => $now,
                'revision' => 0,
            ];
            return $this->storage->createIfAbsent('characters', $id, $record);
        });
    }

    /** Validate the pre-game Lifepath snapshot before attaching it to a permanent character. */
    private static function validateBackgroundSnapshot(array $background, string $speciesId): array
    {
        if (($background['locked'] ?? false) !== true) {
            throw new RuntimeException('Lock the generated character history before saving the character.');
        }
        if (($background['species_key'] ?? null) !== $speciesId) {
            throw new RuntimeException('The Lifepath species must match the character species.');
        }
        $age = filter_var($background['age'] ?? null, FILTER_VALIDATE_INT);
        $seed = trim((string)($background['seed'] ?? ''));
        $history = $background['history'] ?? null;
        if ($age === false || $age < 0 || $seed === '' || strlen($seed) > 160 || !is_array($history) || $history === []) {
            throw new RuntimeException('The locked Lifepath snapshot is incomplete.');
        }
        $careerPath = $background['career_path'] ?? null;
        $allowedPaths = ['education', 'military', 'employment', 'independent'];
        if ($careerPath !== null && (!is_array($careerPath) || !in_array($careerPath['id'] ?? '', $allowedPaths, true))) {
            throw new RuntimeException('The selected Lifepath direction is invalid.');
        }
        $race = is_array($background['race'] ?? null) ? $background['race'] : [];
        $maturationAge = filter_var($background['maturation_age'] ?? null, FILTER_VALIDATE_INT);
        $maximumAge = filter_var($background['max_allowable_age'] ?? null, FILTER_VALIDATE_INT);
        if ($maturationAge === false || $maximumAge === false || $age < $maturationAge || $age > $maximumAge) {
            throw new RuntimeException('The Lifepath age is outside the species age limits.');
        }
        return [
            'schema_version' => 1,
            'locked' => true,
            'locked_at' => gmdate('c'),
            'generator' => 'CORE Lifepath',
            'generator_version' => '1',
            'species_key' => $speciesId,
            'race' => ['key' => $speciesId, 'name' => (string)($race['name'] ?? $speciesId)],
            'seed' => $seed,
            'age' => (int)$age,
            'maturation_age' => (int)$maturationAge,
            'graduation_age' => (int)($background['graduation_age'] ?? 0),
            'max_allowable_age' => (int)$maximumAge,
            'career_path' => $careerPath,
            'siblings' => is_array($background['siblings'] ?? null) ? array_values($background['siblings']) : [],
            'history' => array_values($history),
        ];
    }

    /** Move a character within its universe. Repeated same-destination requests are idempotent. */
    public function move(string $universeId, string $characterId, string $systemId, int $expectedRevision): array
    {
        $universeId = trim($universeId);
        $characterId = trim($characterId);
        $systemId = trim($systemId);
        if ($universeId === '' || $characterId === '' || $systemId === '') {
            throw new RuntimeException('universe_id, character_id, and system_id are required.');
        }
        if ($expectedRevision < 0) throw new RuntimeException('Expected character revision must be zero or greater.');

        $universe = $this->storage->read('universes', $universeId);
        if ($universe === null || ($universe['id'] ?? null) !== $universeId) {
            throw new RuntimeException('The selected universe does not exist.');
        }
        UniverseLifecycleGuard::assertCanPerformGameplayAction($universe);
        $systems = $universe['baseline']['systems'] ?? null;
        if (!is_array($systems)) throw new RuntimeException('The selected universe has no valid system list.');
        $systemsById = [];
        foreach ($systems as $system) {
            if (is_array($system) && isset($system['id'])) $systemsById[(string)$system['id']] = $system;
        }
        $target = $systemsById[$systemId] ?? null;
        if (!is_array($target)) throw new RuntimeException('Target system does not belong to the selected universe.');
        $navigation = NavigationGraph::build($systems);
        $movementStatus = 'moved';
        $result = $this->storage->transact('characters', $characterId, static function (array $character) use ($universeId, $systemId, $expectedRevision, $target, $systemsById, $navigation, &$movementStatus): array {
            if (CharacterUniverseContext::activeUniverseId($character) !== $universeId) {
                throw new RuntimeException('Character does not belong to the selected universe.');
            }
            CharacterLifecycleGuard::assertCanPerformGameplayAction($character);
            $actualRevision = (int)($character['revision'] ?? 0);
            if ($actualRevision !== $expectedRevision) {
                throw new RuntimeException('Character revision conflict: expected ' . $expectedRevision . ', current revision is ' . $actualRevision . '.');
            }

            $now = gmdate('c');
            $currentSystemId = (string)($character['current_system_id'] ?? $character['location']['system_id'] ?? '');
            $exploration = $character['exploration'] ?? [];
            if (!is_array($exploration)) $exploration = [];
            $visited = $exploration['explored_systems'] ?? [];
            if (!is_array($visited)) $visited = [];

            // Backfill the current location for older character records without exploration data.
            if ($visited === [] && $currentSystemId !== '' && isset($systemsById[$currentSystemId])) {
                $currentSystem = $systemsById[$currentSystemId];
                $visited[] = [
                    'system_id' => $currentSystemId,
                    'name' => (string)($currentSystem['name'] ?? $currentSystemId),
                    'first_visited_at' => (string)($character['location']['updated_at'] ?? $character['created_at'] ?? $now),
                    'first_visited_revision' => $actualRevision,
                ];
            }

            $alreadyVisited = false;
            foreach ($visited as $entry) {
                if (is_array($entry) && ($entry['system_id'] ?? null) === $systemId) { $alreadyVisited = true; break; }
            }
            $alreadyAtDestination = $currentSystemId === $systemId;
            if (!$alreadyAtDestination && !in_array($systemId, $navigation['neighbors'][$currentSystemId] ?? [], true)) {
                throw new RuntimeException('Target system is not directly reachable from the character current system.');
            }
            if (!$alreadyAtDestination) {
                $character['current_system_id'] = $systemId;
                $character['current_constellation_id'] = (string)($target['constellation_id'] ?? '');
                $character['location'] = ['constellation_id' => (string)($target['constellation_id'] ?? ''), 'system_id' => $systemId, 'updated_at' => $now];
                $character['revision'] = $actualRevision + 1;
                // Manual movement must not leave an old multi-hop route looking executable.
                $routeProgress = $character['route_progress'] ?? null;
                if (is_array($routeProgress) && ($routeProgress['status'] ?? '') === 'active') {
                    $routeProgress['status'] = 'cancelled';
                    $routeProgress['cancelled_at'] = $now;
                    $routeProgress['cancellation_reason'] = 'manual_movement';
                    $routeProgress['updated_at'] = $now;
                    $character['route_progress'] = $routeProgress;
                }
            }
            if (!$alreadyVisited) {
                $visited[] = [
                    'system_id' => $systemId,
                    'name' => (string)($target['name'] ?? $systemId),
                    'first_visited_at' => $now,
                    'first_visited_revision' => $alreadyAtDestination ? $actualRevision : $actualRevision + 1,
                ];
            }
            $exploration['explored_systems'] = array_values($visited);
            $character['exploration'] = $exploration;
            $movementStatus = $alreadyAtDestination ? 'already_at_destination' : 'moved';
            return $character;
        });

        $result['_movement_status'] = $movementStatus;
        return $result;
    }

    /** Character identities are permanent. Use the reversible lifecycle service to disable or restore records. */
    public function deleteCharacter(string $universeId, string $characterId, string $confirmationName, int $expectedRevision): array
    {
        throw new RuntimeException('Permanent character deletion is disabled by policy. Disable the character to archive it; archived records can be restored later.');
    }

    public function navigationForUniverse(string $universeId): array
    {
        $universeId = trim($universeId);
        $universe = $this->storage->read('universes', $universeId);
        if ($universe === null || ($universe['id'] ?? null) !== $universeId) {
            throw new RuntimeException('The selected universe does not exist.');
        }
        return NavigationGraph::build($universe['baseline']['systems'] ?? []);
    }

    /** Return the complete persisted character record, including inventory, exploration, scans, and ship fittings. */
    public function getById(string $characterId): array
    {
        $characterId = trim($characterId);
        if ($characterId === '') throw new RuntimeException('A character_id is required.');
        $character = $this->storage->read('characters', $characterId);
        if ($character === null || ($character['id'] ?? null) !== $characterId) throw new RuntimeException('The selected character does not exist.');
        return $character;
    }

    public function listForUniverse(string $universeId): array
    {
        $universeId = trim($universeId);
        $universe = $this->storage->read('universes', $universeId);
        if ($universe === null || ($universe['id'] ?? null) !== $universeId) {
            throw new RuntimeException('The selected universe does not exist.');
        }
        $characters = array_values(array_filter(
            $this->storage->all('characters'),
            static fn(array $character): bool => ($character['universe_id'] ?? null) === $universeId
        ));
        usort($characters, static fn(array $a, array $b): int => strcmp((string)($a['created_at'] ?? ''), (string)($b['created_at'] ?? '')));
        return $characters;
    }
}
